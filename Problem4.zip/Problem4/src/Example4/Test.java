package Example4;

public class Test {

    public static void main(String[] args) {

        Bicycle mb2 = new MountainBike(3, 4, 5);

        MountainBike mb1 = new MountainBike(6, 7, 8);

        System.out.println("seat height of first bicycle is : " + mb1.seatHeight);
        //System.out.println(""+mb2..seatHeight);  //use only overridden method 

        System.out.println(mb1.toString());
        System.out.println(mb2.toString());

    }
}
