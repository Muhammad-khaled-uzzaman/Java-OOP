
package Example1;

public class Parent extends Grandparent {
    
    @Override
    public void print(){
        System.out.println("Parent's Print()");
    }
}
