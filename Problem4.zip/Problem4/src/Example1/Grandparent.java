/*
Accessing Grandparent’s member in Java using super
*/
package Example1;

public class Grandparent {
    
    public void print(){
        System.out.println("Grandparent's Print()");
    }
}
