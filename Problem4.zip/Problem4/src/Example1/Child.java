package Example1;

public class Child extends Parent {

    @Override
    public void print() {
        //super.super.print();  //// Trying to access Grandparent's Print()
        System.out.println("Child's Print()");
    }
}
