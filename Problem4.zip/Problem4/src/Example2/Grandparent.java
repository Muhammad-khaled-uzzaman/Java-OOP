/*
access grandparent’s members only through the parent class.
*/
package Example2;

public class Grandparent {
    public void print(){
        System.out.println("Grandparent's Print()");
    }
}
