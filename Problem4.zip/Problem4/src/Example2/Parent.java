
package Example2;

public class Parent extends Grandparent {
    
    @Override
    public void print(){
        super.print();
        System.out.println("Parent's Print()");
    }
}
