
package Example2;

public class Child extends Parent {
    
    @Override
    public void print(){
        super.print();
        System.out.println("Child's Print()");
    }
}
