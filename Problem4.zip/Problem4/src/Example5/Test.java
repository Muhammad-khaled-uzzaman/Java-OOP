
package Example5;

import java.util.ArrayList;

public class Test {
    
    public static void main(String[] args) {
        
        ArrayList al = new ArrayList(2);
        
        al.add(new String("Muuhammad Khaled"));
        al.add(new Integer(5));
        
        for(Object object : al){
            System.out.println(object);
        }
        
    }
}
