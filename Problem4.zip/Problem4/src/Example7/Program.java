
package Example7;

public class Program {
    
    public static void main(String[] args) {
        
        Derived ob = new Derived();
        
        System.out.println(ob.f(3));
        System.out.println(ob.f(3.3));
    }
}
