
package Example7;

public class Derived extends Base {
    
    public double f(double i){
        System.out.print("f (double):");
        return i+3;
    }
}
