package Example7;

public class Base {

    public int f(int i) {
        System.out.print("f (int) :");
        return i+3;
    }
}
