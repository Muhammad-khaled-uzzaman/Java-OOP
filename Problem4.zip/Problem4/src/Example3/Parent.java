/*
Parent and Child classes having same data member in Java
*/
package Example3;

public class Parent {
    
    int value=1000;
    Parent(){
        System.out.println("Parent Constructor");
    }
}
