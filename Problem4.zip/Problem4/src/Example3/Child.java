
package Example3;

public class Child extends Parent {
    int value =10;
    Child(){
        System.out.println("Child Constructor");
    }
}
