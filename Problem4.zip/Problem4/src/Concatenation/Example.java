/*
Addition and Concatenation in Java

it encounters the string initially. Basically, Strings take precedence 
because they have a higher casting priority than integers do.
*/
package Concatenation;

public class Example {
    public static void main(String[] args) {
        System.out.println(2+0+1+6+"GeeksforGeeks");
        System.out.println("GeeksforGeeks"+2+0+1+6);
        System.out.println(2+0+1+5+"GeeksforGeeks"+2+0+1+6);
        System.out.println(2+0+1+5+"GeeksforGeeks"+(2+0+1+6));
    }
}
