
package modifier2;

import modifier1.B;

public class D extends B {
    public static void main(String[] args) {
        
        D ob = new D();
        ob.display();
    }
}
