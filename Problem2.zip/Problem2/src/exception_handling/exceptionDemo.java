
package exception_handling;

public class exceptionDemo {
    public static void main(String[] args) {
        try{
            int x = 10;
        int y = 0;
        int [] a  = new int [4];
        a[4] = 10;
        int result = x/y;
        System.out.println("Result : "+result);
        }catch(ArithmeticException e1){
            System.out.println("Exception : "+e1);
        }
        catch(ArrayIndexOutOfBoundsException e2){
            System.out.println("Exception : "+e2);
        }
        catch(Exception e3){
            System.out.println("Exception : "+e3);
        }
        //System.out.println("Last   line of program");
        finally{
            System.out.println("Last   line of program");
        }
        
    }
}
