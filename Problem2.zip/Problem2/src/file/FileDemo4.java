
package file;

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.Scanner;

public class FileDemo4 {
    
    public static void main(String[] args) {
        String id,name;
        try{
            Formatter formatter = new Formatter("G:\\Muhammad Khaled\\Problem2\\Person3/Student.text");
            
            Scanner input = new Scanner(System.in);
            System.out.println("How many student : ");
            int num = input.nextInt();
            
            for (int i = 1; i <=num; i++) {
                System.out.print("Enter student id and name : ");
                id = input.next();
                name = input.next();
                formatter.format("%s %s\r\n",id,name);
            }
            //formatter.format("%s %s\r\n","101","Pinky");
            //formatter.format("%s %s\r\n","102","Muntasir");
            //formatter.format("%s %s\r\n","103","daud");
            //formatter.format("%s %s\r\n","104","Kabir");
            formatter.close();
        }catch(FileNotFoundException e)
        {
            System.out.println(e);
        }
         
    }
}
