
package file;

import java.io.File;

public class FileDemo2 {
    public static void main(String[] args) {
        //folder created
        File dir = new File("Person1");
        dir.mkdir();
        
        String path = dir.getAbsolutePath();
        
        //file created
        
        File file1 = new File(path+"/Student.text");
        File file2 = new File("G:/Muhammad Khaled/Problem2/Person1/Teacher.text");
        
        try{
            
            file1.createNewFile();
            file2.createNewFile();
            System.out.println("File are created");
        }catch(Exception e)
        {
            System.out.println(e);
        }
        
        if(file1.exists())
        {
            System.out.println("File1 exists");
        }
        else
        {
            System.out.println("File1 does not exists");
        }
        
        file2.delete();
        if(file2.exists())
        {
            System.out.println("File2 exists");
        }
        else
        {
            System.out.println("File2 does not exists");
        }
        
        
        
    }
}
