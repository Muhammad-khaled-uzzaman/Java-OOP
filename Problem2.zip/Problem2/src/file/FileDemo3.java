
package file;

import java.io.File;

public class FileDemo3 {
    public static void main(String[] args) {
        //folder created
        File dir = new File("Person3");
        dir.mkdir();
        
        String path = dir.getAbsolutePath();
        
        //file created
        
        File file1 = new File(path+"/Student.text");
        File file2 = new File(path+"/Teacher.text");
        
        try{
            
            file1.createNewFile();
            file2.createNewFile();
            System.out.println("File are created");
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
