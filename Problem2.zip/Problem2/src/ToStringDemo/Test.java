
package ToStringDemo;

public class Test {
    
    public static void main(String[] args) {
        Person p1 = new Person("Khaled",19);
        Person p2 = new Person("Muhammad",20);
        
        System.out.println(p1); //toString
        System.out.println(p2);
    }
}
