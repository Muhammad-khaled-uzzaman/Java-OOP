
package StudentList;

public class Student {
    
    String name,className;
    int id;
    
    Student(int id,String name,String className)
    {
        this.id = id;
        this.name = name;
        this.className = className;
    }
    
    
    
}
