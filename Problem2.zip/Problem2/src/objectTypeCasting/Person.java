
package objectTypeCasting;

public class Person {
    
    void display()
    {
        System.out.println("Person class");
    }
}
