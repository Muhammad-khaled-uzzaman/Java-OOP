
package objectTypeCasting;

public class Teacher extends Person {
    
    void display()
    {
        System.out.println("Teacher class");
    }
}
