
package objectTypeCasting;

public class Test {
    public static void main(String[] args) {
        Person p1 = new Person();
        p1.display();
        Person t = new Teacher();  //upcasting
        t.display();
        
        
        // Teacher t = (Teacher) new Person(); ..downcasting
        //t.display();
        
    }
}

