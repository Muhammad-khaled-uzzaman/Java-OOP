
package modifier1;

public class B {
    
    protected void display()
    {
        System.out.println("Hi Janu");
    }
            
}
