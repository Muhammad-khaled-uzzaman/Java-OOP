
package Problem_solving;

import java.text.DecimalFormat;

public class DecimalNumberFormatDemo {
    public static void main(String[] args) {
        DecimalFormat ob = new DecimalFormat("0.00");
        
        double x = 2.14562789;
 
        System.out.println("X = "+ob.format(x));

    }
}
