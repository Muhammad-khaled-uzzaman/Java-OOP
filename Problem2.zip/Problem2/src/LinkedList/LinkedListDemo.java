
package LinkedList;

import java.util.LinkedList;

public class LinkedListDemo {
    public static void main(String[] args) {
        
        LinkedList<String>countryNames = new LinkedList<String>();
        
        countryNames.add("Afghanistan");
        countryNames.add("Bangladesh");
        countryNames.add("India");
        countryNames.add("Pakistan");
        countryNames.add("Nepal");
        
        //System.out.println(countryNames);
        
        for(String country : countryNames)
        {
            System.out.println(country);
        }
        
    }
}
