
package Problem;

public class dataType {
    public static void main(String[] args) {
        
        int x=10;
        double y=x;
        System.out.println(y);
        
        double a=10.5;
        int b = (int) a;
        System.out.println(b);
    }
}
