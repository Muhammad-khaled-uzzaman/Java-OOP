
package newOperator;

public class Box {
    
    double width;
    double height;
    double depth;
    
    
}
