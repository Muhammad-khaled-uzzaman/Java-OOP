
package multipleInterface2;

public interface PI2 extends GPI {
    
}
