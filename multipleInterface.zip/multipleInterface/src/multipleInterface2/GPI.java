/*
// A simple Java program to demonstrate how diamond 
// problem is handled in case of default methods 
 */
package multipleInterface2;

public interface GPI {

    default void show() {
        System.out.println("Default GPI");
    }
}
