
package multipleInterface2;

public class TestClass implements PI1,PI2 {
    
    public static void main(String[] args) {
        TestClass d = new TestClass();
        d.show();
        
       
    }
}
