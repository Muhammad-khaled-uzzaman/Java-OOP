
package multipleInterface2;

public interface PI1 extends GPI {
    
}
