// A simple Java program to demonstrate multiple 
// inheritance through default methods. 
package multipleInterface;

public interface PI1 {

    default void show() {
        System.out.println("Default PI1");
    }
}
