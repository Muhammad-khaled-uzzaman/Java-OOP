//Java program to demonstrate Integer.parseInt() method 
package parseInt;

public class Test {
    
    public static void main(String[] args) {
       int z = Integer.parseInt("654",8);
       int a = Integer.parseInt("-FF",16);
       long l = Long.parseLong("21456987",10);
       
        System.out.println(z);
        System.out.println(a);
        System.out.println(l);
         // run-time NumberFormatException will occur here 
        // "Geeks" is not a parsable string 
        int x = Integer.parseInt("Geek",8);
        
         // run-time NumberFormatException will occur here 
        // (for octal(8),allowed digits are [0-7]) 
        int y = Integer.parseInt("99",8);
    }
}
