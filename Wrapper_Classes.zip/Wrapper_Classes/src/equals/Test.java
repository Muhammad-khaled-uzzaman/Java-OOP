/*
//Java program to demonstrate equals() method 
*/
package equals;

public class Test {
    
    public static void main(String[] args) {
        
        // creating a Short Class object with value "15" 
        Short s = new Short("15");
       
        // creating a Short Class object with value "10" 
        Short x = 10;
        
        Integer y = 15;
        
        Short z = 15;
        
        System.out.println(s.equals(x));
        System.out.println(s.equals(y));
        System.out.println(s.equals(z));
    }
}
