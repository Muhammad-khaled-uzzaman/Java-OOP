
package boolean_test;

public class Test6 {
    
    public static void main(String[] args) {
         // creating different Boolean objects 
        Boolean b1 = new Boolean("True"); 
        Boolean b2 = new Boolean("False"); 
        Boolean b3 = new Boolean("TRue"); 
        Boolean b4 = new Boolean(null); 
        
        System.out.println(b1.hashCode());
        System.out.println(b2.hashCode());
        System.out.println(b3.hashCode());
        System.out.println(b4.hashCode());
    }
}
