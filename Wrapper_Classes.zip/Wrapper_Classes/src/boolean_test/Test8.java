
package boolean_test;

public class Test8 {
    
    public static void main(String[] args) {
        // creating different Boolean objects 
        Boolean b1 = new Boolean("True"); 
        Boolean b2 = new Boolean("False"); 
        Boolean b3 = new Boolean("TRue"); 
        Boolean b4 = new Boolean(null); 
        
         //comparing b1,b2,b3,b4 
        System.out.println(b1.compareTo(b2)); 
        System.out.println(b1.compareTo(b3)); 
        System.out.println(b2.compareTo(b1)); 
        System.out.println(b1.compareTo(b4)); 
        System.out.println(b2.compareTo(b4)); 
          
        // The following statement throws NullPointerExcetion 
        //  System.out.println(b1.compareTo(null)
    }
}
