
package character_test;

public class Test1 {
    
    public static void main(String[] args) {
        
        System.out.println(Character.isDigit('0'));
        System.out.println(Character.isDigit('A'));
    }
}
