
package character_test;

public class Test {
    
    public static void main(String[] args) {
        
        System.out.println(Character.isLetter('A'));
        System.out.println(Character.isLetter('0'));
    }
}
