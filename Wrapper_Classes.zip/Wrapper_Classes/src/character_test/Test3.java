
package character_test;

public class Test3 {
    
    public static void main(String[] args) {
        System.out.println(Character.isUpperCase('A'));
        System.out.println(Character.isUpperCase('a'));
        System.out.println(Character.isUpperCase(65));
    }
}
