package character_test;

public class Test7 {

    public static void main(String[] args) {
        System.out.println(Character.toString('x'));
        System.out.println(Character.toString('Y'));
    }
}
