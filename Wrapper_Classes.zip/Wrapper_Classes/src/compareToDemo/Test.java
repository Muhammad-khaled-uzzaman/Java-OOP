/*
the value 0 if the Number is equal to the argument.
the value -1 if the Number is less than the argument.
the value 1 if the Number is greater than the argument.
*/
//int compareTo(NumberSubClass referenceName) :
package compareToDemo;

public class Test {
    
    public static void main(String[] args) {
        
        // creating an Integer Class object with value "10" 
        Integer i = new Integer(10);
        
        System.out.println(i.compareTo(7));
        System.out.println(i.compareTo(10));
        System.out.println(i.compareTo(12));
    }
}
