package Integer_test_1;

public class Test {

    public static void main(String[] args) {
        int b = 55;
        String bb = "45";

        // Construct two Integer objects 
        Integer x = new Integer(b);
        Integer y = new Integer(bb);

        // xxxValue can be used to retrieve 
        // xxx type value from int value. 
        // xxx can be int,byte,short,long,double,float 
        System.out.println("bytevalue(x) = " + x.byteValue());
        System.out.println("shortvalue(x) = " + x.shortValue());
        System.out.println("intvalue(x) = " + x.intValue());
        System.out.println("longvalue(x) = " + x.longValue());
        System.out.println("doublevalue(x) = " + x.doubleValue());
        System.out.println("floatvalue(x) = " + x.floatValue());

        int value = 45;

        // bitcount() : can be used to count set bits 
        // in twos complement form of the number 
        System.out.println("Integer.bitcount(value)=" + Integer.bitCount(value));

        // numberOfTrailingZeroes and numberOfLeaadingZeroes 
        // can be used to count prefix and postfix sequence of 0 
        System.out.println("Integer.numberOfTrailingZeros(value)="
                + Integer.numberOfTrailingZeros(value));
        System.out.println("Integer.numberOfLeadingZeros(value)="
                + Integer.numberOfLeadingZeros(value));

        //highestOneBit returns a value with one on highest  
        //set bit position 
        System.out.println("Integer.highestOneBit(value)="
                + Integer.highestOneBit(value));
        // highestOneBit returns a value with one on lowest  
        // set bit position 
        System.out.println("Integer.lowestOneBit(value)="
                + Integer.lowestOneBit(value));

        // reverse() can be used to reverse order of bits 
        // reverseytes() can be used to reverse order of bytes 
        System.out.println("Integer.reverse(value)="
                + Integer.reverse(value));
        System.out.println("Integer.reverseBytes(value)="
                + Integer.reverseBytes(value));

        // signum() returns -1,0,1 for negative,0 and positive  
        // values 
        System.out.println("Integer.signum(value)=" + Integer.signum(value));

        // hashcode() returns hashcode of the object 
        int hash = x.hashCode();
        System.out.println("hashcode(x) = " + hash);

        // equals returns boolean value representing equality 
        boolean eq = x.equals(y);
        System.out.println("x.equals(y) = " + eq);

        // compare() used for comparing two int values 
        int e = Integer.compare(x, y);
        System.out.println("compare(x,y) = " + e);

        // compareTo() used for comparing this value with some 
        // other value 
        int f = x.compareTo(y);
        System.out.println("x.compareTo(y) = " + f);
    }
}
