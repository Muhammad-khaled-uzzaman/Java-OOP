/*
Since radix is 27,so allowed characters in a String literal are 
[0-9],[A-Q](for 10 to 26).So its value will calculated as follows:
 */
package OutputExample;

public class Test {

    public static void main(String[] args) {
        Integer i = Integer.parseInt("kona", 27);
        System.out.println(i);
    }
}
