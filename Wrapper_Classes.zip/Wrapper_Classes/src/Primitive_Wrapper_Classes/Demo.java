/*
Primitive Wrapper Classes are Immutable in Java
 */
// Java program to demonstrate that prmitive 
// wrapper classes are immutable 
package Primitive_Wrapper_Classes;

public class Demo {

    public static void main(String[] args) {
        Integer i = new Integer(10);

        System.out.println(i);

        modify(i);
        System.out.println(i);

    }

    public static void modify(Integer i) {
        i = i + 1;

    }
}
