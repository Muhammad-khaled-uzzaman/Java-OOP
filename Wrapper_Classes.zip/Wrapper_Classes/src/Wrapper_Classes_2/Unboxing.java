/*
Unboxing:For example – conversion of Integer to int, Long to long, Double to double etc.
 */
package Wrapper_Classes_2;

import java.util.ArrayList;

public class Unboxing {

    public static void main(String[] args) {

        Character ch = 'a';

        // unboxing - Character object to primitive conversion 
        char c = ch;

        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(20);

        int num = arrayList.get(0);
        System.out.println(num);
        System.out.println(ch);

        System.out.println(c);
    }

}
