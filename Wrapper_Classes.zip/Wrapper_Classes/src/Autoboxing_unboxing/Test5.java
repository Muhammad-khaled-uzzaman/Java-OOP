package Autoboxing_unboxing;

import java.util.ArrayList;
import java.util.List;

public class Test5 {

    public static void main(String[] args) {

        ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(6);
        list.add(7);
        list.add(8);
        list.add(9);
        list.add(10);

        int sumEven = sumOfEvenNumber(list);
        System.out.println(sumEven);
    }

    public static int sumOfEvenNumber(List<Integer> list) {
        int sum = 0;
        for (Integer i : list) {
            if (i % 2 == 0) {
                sum += i;
            }
        }
        return sum;
    }
}
