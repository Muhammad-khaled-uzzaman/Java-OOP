
package Primitive_Wrapper_Classes_2;

public class Demo {
    
    public static void main(String[] args) {
        Integer  i = new Integer(10);
        System.out.println(i);
        
        i = i +10;
        System.out.println(i);
    }
}
