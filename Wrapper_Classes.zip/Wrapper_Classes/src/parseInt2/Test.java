/*
Syntax : 
static int parseInt(String s)
Parameters : 
s - any String representation of decimal
Returns :
the integer value represented by the argument in decimal.
Throws :
NumberFormatException : if the string does not contain a parsable integer.
 */
package parseInt2;

public class Test {

    public static void main(String[] args) {
        int x = Integer.parseInt("654");
        long y = Long.parseLong("212314566");

        System.out.println(x);
        System.out.println(y);

        // run-time NumberFormatException will occur here 
        // "Geeks" is not a parsable string 
        int z = Integer.parseInt("Geeks");

        // run-time NumberFormatException will occur here 
        // (for decimal(10),allowed digits are [0-9]) 
        int a = Integer.parseInt("-FF");
    }
}
