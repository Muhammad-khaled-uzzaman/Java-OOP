/*
Syntax : 
String toString()
String toString(int i)
Parameters : 
String toString() - no parameter
String toString(int i) - i: any integer value
Returns :
String toString() -
returns a String object representing the value of the Number object 
on which it is invoked.
String toString(int i) -
returns a decimal String object representing the specified integer(i)
*/
package String_toString;

public class Test {
    public static void main(String[] args) {
        
        Integer x = 12;
        
        System.out.println(x.toString());
        
        System.out.println(Integer.toString(12));
        
        System.out.println(Integer.toBinaryString(152));
        System.out.println(Integer.toOctalString(152));
        System.out.println(Integer.toHexString(152));
    }
}
