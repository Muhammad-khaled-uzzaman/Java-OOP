/*
Autoboxing: conversion of int to Integer, long to Long, double to Double etc.
*/
// Java program to demonstrate Autoboxing 
package Wrapper_Classes_1;

import java.util.ArrayList;

public class Autoboxing {
    
    public static void main(String[] args) {
        
        char ch ='a';
        
        // Autoboxing- primitive to Character object conversion 
        Character a = ch;
        
        ArrayList<Integer>arrayList = new ArrayList<Integer>();
        
        arrayList.add(10);
        
        System.out.println(arrayList.get(0));
    }
}
