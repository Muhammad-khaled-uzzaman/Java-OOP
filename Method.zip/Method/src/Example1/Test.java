package Example1;

public class Test {

    public static void main(String[] args) {
        Addition ob = new Addition();
        int s = ob.addTwoInt(5, 10);
        System.out.println("Sum of two integer values : " + s);
    }
}
