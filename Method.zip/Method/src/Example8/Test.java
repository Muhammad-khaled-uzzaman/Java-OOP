/*
Program 1: This Program shows what results print if one doesn’t 
use fillInStackTrace() method and what happens if one uses fillInStackTrace() method
*/
package Example8;

public class Test {
    public static void main(String[] args) throws Throwable {
        Test t = new Test();
        try{
            t.method();
        }catch(Exception e){
            System.out.println("Exception details without fillInStackTrace()\n");
            System.out.println("Caught Inside Main:");
            e.printStackTrace();
            
            System.out.println("Exception details with fillInStackTrace()\n");
            System.out.println("Caught Inside Main :");
            e.fillInStackTrace();
            e.printStackTrace();
        }
    }
    public void method() throws Throwable{
        divide();
    }
    void divide(){
        try{
            System.out.println(10/0);
        }catch(ArithmeticException e){
            throw e;
        }
    }
    
}
