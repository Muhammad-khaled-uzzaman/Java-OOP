/*
Changes are reflected back if we do not assign reference to a new location or object:
*/
// A Java program to show that we can change members using using 
// reference if we do not change the reference itself. 
package GeeksforGeeksExample3;

public class Test {
    
    int x;
    Test(int x){
        this.x = x;
    }
    Test(){
        x = 0;
    }
}
