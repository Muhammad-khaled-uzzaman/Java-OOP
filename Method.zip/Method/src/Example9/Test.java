/*
the main() method is showing whole exception details because fillInStackTrace() 
was not called in main method.
 */
package Example9;

public class Test {

    public static void main(String[] args) throws Throwable {

        Test t = new Test();
        try {
            t.showResultS();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    // method calling exceptionThrownMethod() 
    // and when method returns Exception 
    // it is calling fillInStackTrace() method 
    public void showResultS() throws Throwable {
        try {
            exceptionThrownMethod();
        } catch (Exception e) {
            e.printStackTrace();
            throw e.fillInStackTrace();
        }
    }

    // method throwing exception 
    public void exceptionThrownMethod() throws Exception {
        throw new Exception("this is thrown from function1()");
    }
}
