
package Example6;

public class Test {
    
    static MultiDivAdd getMultiDivAdd(int a,int b){
        return new MultiDivAdd(a*b,(double)a/b,(a+b));
    }
    public static void main(String[] args) {
        
        MultiDivAdd ans = getMultiDivAdd(10,20);
        System.out.println("Multiplication : "+ans.mul);
        System.out.println("Division : "+ans.div);
        System.out.println("Addition : "+ans.add);
    }
}
