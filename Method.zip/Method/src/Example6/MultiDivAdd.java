/*
If there are more than two returned values
We can encapsulate all returned types into a class and then return an object of that class.

Let us have a look at the following code
*/
package Example6;

public class MultiDivAdd {
    int mul;
    double div;
    int add;
    
     MultiDivAdd(int m,double d,int a){
         mul = m;
         div = d;
         add = a;
     }
}
