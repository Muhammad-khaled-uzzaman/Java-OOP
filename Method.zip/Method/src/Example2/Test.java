
package Example2;

public class Test {
    public static int i = 0;
    
    Test(){
        i++;
    }
    public static int get(){
        return i;
    }
    
    public int m1(){
        System.out.println("Inside the method m1 by object of GFG class");
        m2();
        return 1;
    }
    public void m2(){
        System.out.println("In method m2 came from method m1");
    }
}
