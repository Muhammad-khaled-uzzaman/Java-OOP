
package Example2;

public class Main {
    public static void main(String[] args) {
        
        Test ob = new Test();
        int i = ob.m1();
        System.out.println("Control returned after method m1 : "+i);
        
        int no_of_objects = Test.get();
        System.out.print("No of instances created till now : ");
        System.out.println(no_of_objects);
        
    }
}
