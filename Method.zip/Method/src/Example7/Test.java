
package Example7;
import java.util.*;
public class Test {
    
    public final List<Object> getDetails(){
        String name ="Muhammad";
        int age = 19;
        char gender = 'M';
        return  Arrays.asList(name,age,gender);
    }
    public static void main(String[] args) {
        Test ob =new Test();
        List<Object>person = ob.getDetails();
        System.out.println(person);
    }
   
}
