/*
If returned elements are of different types

Using Pair (If there are only two returned values)
*/
// Returning a pair of values from a function 
package Example5;

import javafx.util.Pair;

public class Test {
    public static Pair<Integer, String> getTwo(){
        return new Pair<Integer, String>(10, "Muhammad");
    }
    
    public static void main(String[] args) {
        Test ob = new Test();
        Pair<Integer, String> p =ob.getTwo();
        System.out.println(p.getKey()+" "+p.getValue());
    }
}
