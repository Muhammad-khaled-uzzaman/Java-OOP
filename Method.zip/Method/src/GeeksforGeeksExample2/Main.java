package GeeksforGeeksExample2;

public class Main {

    public static void main(String[] args) {

        Test t = new Test(5);
        // Reference is passed and a copy of reference 
        // is created in change() 
        change(t);
        System.out.println(t.x);

        Test t1 = new Test();
        System.out.println(t1.x);

    }

    public static void change(Test t) {
        // We changed reference to refer some other location 
        // now any changes made to reference are not reflected 
        // back in main 
        t = new Test();
        t.x = 10;
        
    }
}
