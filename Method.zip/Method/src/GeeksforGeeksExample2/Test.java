/*
The changes are not reflected back if we change the object 
itself to refer some other location or object
*/
package GeeksforGeeksExample2;

public class Test {
    
    int x;
    Test(int i){
        x = i;
    }
    Test(){
        x = 20;
    }
}
