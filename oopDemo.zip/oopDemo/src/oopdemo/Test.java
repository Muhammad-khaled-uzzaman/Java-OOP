
package oopdemo;

public class Test {
    public static void main(String[] args) {
        Teacher teacher1;
        teacher1 = new Teacher();
        
        /*
        teacher1.name = "Muhammad Khaleduzzaman";
        teacher1.gender = "Male";
        teacher1.phone = 1521431037;
        */
        
        teacher1.setInformation("Muhammad Khaleduzzaman","Male",152431037);
        teacher1.displayInformation();
        /*
        System.out.println("Name = "+teacher1.name);
        System.out.println("Gander = "+teacher1.gender);
        System.out.println("Phone = "+teacher1.phone);
        */
        
        
        Teacher teacher2;
        teacher2 = new Teacher();
        /*
        teacher2.name = " Khaleduzzaman";
        teacher2.gender = "Male";
        teacher2.phone = 521431037;
        */
        teacher2.setInformation("Khaleduzzaman", "Male", 521431037);
        teacher2.displayInformation();
        /*
        System.out.println("Name = "+teacher2.name);
        System.out.println("Gander = "+teacher2.gender);
        System.out.println("Phone = "+teacher2.phone);
         */
        
    }
}
