
package superKey;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        
       
        Scanner input = new Scanner(System.in);
        String Color;
        System.out.print("Enter any Color :");
        Color = input.nextLine();
        
        int Weight;
        System.out.print("Enter car weight : ");
        Weight= input.nextInt();
        
        int Gear;
        System.out.print("Enter gear : ");
        Gear = input.nextInt();
        
        Car Volbo = new Car(Color,Weight,Gear);
        Volbo.attribute();
        
        
    }
}
