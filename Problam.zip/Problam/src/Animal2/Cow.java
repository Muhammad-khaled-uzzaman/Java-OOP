
package Animal2;

public class Cow {
    
}
