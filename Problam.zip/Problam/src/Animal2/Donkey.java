
package Animal2;

public class Donkey {
    
    
}
