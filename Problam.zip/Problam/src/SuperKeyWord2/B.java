
package SuperKeyWord2;

public class B extends A {
    
    B()
    {
        super();
        System.out.println("B's Constructor");
    }
}
