
package SuperKeyWord2;

public class A {
    A()
    {
        System.out.println("A's Constructor");
    }
          
}
