
package ThisKeyWord;

public class Test {
    public static void main(String[] args) {
        
     Person p1 = new Person("Khaled",19);
     p1.display();
     
     System.out.println();
     
     Person p2 = new Person("Khaled",19,"Black");
     p2.display();
      
    }
}
