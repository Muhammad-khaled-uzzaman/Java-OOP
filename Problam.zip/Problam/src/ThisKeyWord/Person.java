
package ThisKeyWord;

public class Person {
    
    String name;
    int age;
    String hairColor;
    
    Person(String name,int age)
    {
        this.name = name;
        this.age = age;
    }
    
     
    Person(String name,int age,String hairColor)
    {
        this(name,age);
        this.hairColor = hairColor;
    }
    
    void display()
    {
        this.message();
        System.out.println();
        System.out.println("Name : "+name);
        System.out.println("Age : "+age);
        System.out.println("Hair Color : "+hairColor);
    }
    
    void message()
    {
        System.out.println("I am Message Method");
    }
           
}
