
package Animal1;
import Animal2.Cow;
import Animal2.Donkey;
public class Dog {
    public static void main(String[] args) {
        Cow cow = new Cow();
        Donkey donkey = new Donkey();
                
    }
}
