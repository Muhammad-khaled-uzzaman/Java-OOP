
package Animal1;

public class Cat {
    public static void main(String[] args) {
        
        Animal2.Dog dog = new Animal2.Dog();
        
    }
}
