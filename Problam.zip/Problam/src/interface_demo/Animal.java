
package interface_demo;


public interface Animal {
    
    public abstract void eat();
    
}
