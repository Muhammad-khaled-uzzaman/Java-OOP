
package Method_Overriding;

public class Test {
    public static void main(String[] args) {
        
        Teacher t = new Teacher();
        t.name = "Khaled";
        t.age = 19;
        t.qualification = "BSc in CSE";
        t.displayInformation();
        
        System.out.println();
        
        Person p = new Person();
        p.name = "Muhsin";
        p.age =21;
        p.displayInformation();
        
        
    }
}
