
package Method_Overriding;

public class Person {
    
    String name;
    int age;
    
    void displayInformation()
    {
        System.out.println("Name : "+name);
        System.out.println("Age : "+age);
    }
            
            
}
