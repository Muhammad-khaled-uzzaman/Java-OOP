
package problam;

public class MathDemo {
    public static void main(String[] args) {
        int x = Math.abs(-10);
        System.out.println("x = "+x);
        System.out.println(Math.sqrt(25));
        System.out.println(Math.pow(8, 2));
        System.out.println(Math.PI);
        System.out.println(Math.log(1));
        System.out.println(Math.exp(1));
        System.out.println(Math.max(-2.3, 12));
        System.out.println(Math.min(20, -2));
        System.out.println(Math.ceil(2.3));
        System.out.println(Math.floor(-2.2));
        System.out.println(Math.acos(0));
    }
}
