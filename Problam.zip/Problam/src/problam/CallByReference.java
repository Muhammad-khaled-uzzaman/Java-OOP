
package problam;

public class CallByReference {
     String name;
    void Change(CallByReference r2)
    {
       r2.name = "Rubel";
    }
}
