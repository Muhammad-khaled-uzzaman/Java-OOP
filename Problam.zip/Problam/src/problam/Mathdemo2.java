
package problam;

public class Mathdemo2 {
    public static void main(String[] args) {
        System.out.println(Math.abs(-8));
    }
}
