
package problam;

public class OverLoading {
    
    void add(int a,int b)
    {
        System.out.println(a+b);
    }
    void add(double a,double b)
    {
        System.out.println(a+b);
    }
    void add(int a,int b,int c)
    {
        System.out.println(a+b+c);
    }
    void add()
    {
        System.out.println("Nothing to add");
    }
    
    public static void main(String[] args) {
        OverLoading oL1 = new OverLoading();
        oL1.add(5, 10);
        
        OverLoading oL2 = new OverLoading();
        oL2.add(5.60, 12.20);
        
        OverLoading oL3 = new OverLoading();
        oL3.add(5, 10, 15);
        
        OverLoading oL4 = new OverLoading();
        oL4.add();
    }
}
