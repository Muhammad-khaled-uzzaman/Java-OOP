
package problam;

public class Test {
    public static void main(String[] args) {
        Box box1 = new Box(10,10,10);
        box1.displayVol();
        
        Box box2 = new Box(20,20,20);
        box2.displayVol();
        
        
    }
}
