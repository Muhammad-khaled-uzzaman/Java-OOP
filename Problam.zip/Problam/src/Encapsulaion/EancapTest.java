
package Encapsulaion;

public class EancapTest {
    public static void main(String[] args) {
        
        Person p1 = new Person();
        p1.name = "Khaled";
        p1.age = 19;
        
        p1.display();
    }
}
