
package SuperKeyWord;

public class MethodTest {
    public static void main(String[] args) {
        MethodB ob = new MethodB();
        
        ob.display();
    }
}
