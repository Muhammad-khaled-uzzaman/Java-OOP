
package SuperKeyWord;

public class A {
    
    int x = 10;
    
}
