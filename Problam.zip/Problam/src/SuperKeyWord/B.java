
package SuperKeyWord;

public class B extends A {
    
    int x = 7;
    
    void display()
    {
        System.out.println(super.x);
        System.out.println(x);
    }
    
}
