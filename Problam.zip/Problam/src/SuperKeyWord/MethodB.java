
package SuperKeyWord;

public class MethodB extends MethodA {
    
    @Override
    void display()
    {
        super.display();
        System.out.println("Inside B class");
        Message();
    }
}
