
package SuperKeyWord;


public class MethodA {
    
    
    void display()
    {
        System.out.println("Inside A class");
    }
    
    void Message()
    {
        System.out.println("Abul");
    }
    
    
           
}
