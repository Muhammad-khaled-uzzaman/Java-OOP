
package interface_demo2;

public interface B {
    
    void play();
}
