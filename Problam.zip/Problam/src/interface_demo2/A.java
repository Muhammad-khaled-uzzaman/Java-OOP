
package interface_demo2;

public interface A {
    
    void play();
}
