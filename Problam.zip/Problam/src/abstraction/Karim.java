
package abstraction;

public class Karim extends MobailUser {
    
    
    @Override
    void sendMessage()
    {
        System.out.println("Hi,I am Karim");
    }
}
