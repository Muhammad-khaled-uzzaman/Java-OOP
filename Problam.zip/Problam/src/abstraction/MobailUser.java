
package abstraction;

public abstract class MobailUser {
    
    
    void call()
    {
        System.out.println("Call Method");
    }
    abstract void sendMessage();
}
