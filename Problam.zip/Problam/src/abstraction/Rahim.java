
package abstraction;

public class Rahim extends MobailUser {
    
    @Override
    void sendMessage()
    {
        System.out.println("Hi,I am Rahim");
    }
}
