
package final_KeyWord;

public class Test {
    public static void main(String[] args) {
        
        Univarsity varsity = new Univarsity();
        varsity.display();
    }
}
