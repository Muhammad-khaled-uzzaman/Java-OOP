
package final_KeyWord;

public class Univarsity {
    final String UNIVARSITY_NAME="Aust";
    final int fees;      //blank final variable
    //static final int fees;  //static blanl final variable
    
    
   /*
    static()
    {
      
    }
*/
   
    
    
    Univarsity()
    {
        fees = 80000;
    }
    
    
    void display()
    {
        System.out.println("Univarsity Name : "+UNIVARSITY_NAME);
        System.out.println("Fees : "+fees);
    }
}
