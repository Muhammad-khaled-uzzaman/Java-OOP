
package final_KeyWord2;

public class Student extends Univarsity {
   
      void display2()
    {
        System.out.println("Student Info");
    }
}
