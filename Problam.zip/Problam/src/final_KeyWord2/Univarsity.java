
package final_KeyWord2;

public class Univarsity {
    
    final void display()
    {
        System.out.println("Univarsity Info");
    }
}
