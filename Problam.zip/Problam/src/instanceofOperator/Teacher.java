
package instanceofOperator;

public class Teacher extends Person {
    
}
