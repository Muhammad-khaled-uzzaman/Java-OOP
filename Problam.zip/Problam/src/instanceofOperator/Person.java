
package instanceofOperator;

public class Person extends Animal {
    
}
