
package instanceofOperator;

public class Animal {
    
}
