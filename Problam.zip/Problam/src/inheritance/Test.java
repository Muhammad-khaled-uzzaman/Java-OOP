
package inheritance;

public class Test {
    public static void main(String[] args) {
        Teacher t1 = new Teacher();
        
        t1.name = "Aminul";
        t1.age = 27;
        t1.qualification = "MSc in CSE";
        
        t1.displayInformation2();
        
        System.out.println();
        
        Teacher t2 = new Teacher();
        
        t2.name = "Murad";
        t2.age = 26;
        t2.qualification = "BSc in CSE";
        
        t2.displayInformation2();
    }
}
