
package Polymorphism;

public class Test {
    public static void main(String[] args) {
        
        Shape s1 = new Shape();
        System.out.println(s1.area());
    
        //Rectanglee r = new Rectangle(10,20);
        Shape s2 = new Rectangle(10,20);  //Dynamic polymorphism
        double result = s2.area();
        System.out.println("Rectangle Area = "+result);
        
        //STriangle t = new Triangle(10,20);
        Shape s3 = new Triangle(10,20);
        double res = s3.area();
        System.out.println("Triangle Area = "+res);
    }
}
