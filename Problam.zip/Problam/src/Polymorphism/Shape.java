
package Polymorphism;

public class Shape {
    
    double area()
    {
        System.out.print("Area for Shape : ");
        return 0;
    }
}
