
package Call;

public class CallByValue {
    void Change(int i)
    {   
        //System.out.println(i);
        i = 20;
        //System.out.println(i);
        
    }
}
