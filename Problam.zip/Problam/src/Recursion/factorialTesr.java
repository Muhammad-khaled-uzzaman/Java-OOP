
package Recursion;

public class factorialTesr {
    public static void main(String[] args) {
        factorialDemo ob = new factorialDemo();
        
        int result = ob.fact(5);
        System.out.println("Factorial of 5 : "+result);
        
        result = ob.fact(4);
        System.out.println("Factorial of 4 : "+result);
    }
}
