
package inheritancePrivateMember;

public class Test {
    public static void main(String[] args) {
        Teacher t1 = new Teacher();
        
        t1.setName("Aminul");
        t1.setAge(28);
        t1.setQualification("MSc in CSE");
        
        t1.displayInformatin();
        
        System.out.println();
        
        Teacher t2= new Teacher();
        
        t2.setName("Murad");
        t2.setAge(26);
        t2.setQualification("BSc in CSE");
        
        t2.displayInformatin();
    }
}
