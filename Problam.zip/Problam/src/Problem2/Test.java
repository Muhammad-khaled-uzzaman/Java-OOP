
package Problem2;

public class Test {
    public static void main(String[] args) {
        
        Shape sh;
        
        sh = new Rectangle(10,20);
        sh.area();
        
        sh = new Triangle(10,10);
        sh.area();
        
        sh = new Circle(5);
        sh.area();
        
        
        
       
    }
}
