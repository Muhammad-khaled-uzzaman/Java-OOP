// Java program to demonstrate working of 
// interface inside a class. 
package Nested_Interface_1;

public class Test {

    interface Yes{
        void show();
    }
}
