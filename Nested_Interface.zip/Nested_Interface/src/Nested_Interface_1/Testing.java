
package Nested_Interface_1;

public class Testing implements Test.Yes {
    
    @Override
    public void show(){
        System.out.println("show method of interface"); 
    }
}
