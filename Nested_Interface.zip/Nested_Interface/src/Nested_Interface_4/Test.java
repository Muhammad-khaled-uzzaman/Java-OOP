/*
 interface members can only be public..
*/
package Nested_Interface_4;

public interface Test {
    /*
    protected interface(){
    
}
*/
}
