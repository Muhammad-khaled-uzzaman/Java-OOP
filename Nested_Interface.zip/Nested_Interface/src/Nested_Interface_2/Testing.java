
package Nested_Interface_2;

public class Testing implements Test.Yes {
    
    @Override
    public void show(){
        System.out.println("show method of interface");
    }
}
