/*
// Java program to demonstrate protected  
// specifier for nested interface.
 We can assign public, protected or private also. Below is an example of protected
*/
package Nested_Interface_2;

public class Test {
    
    protected interface Yes{
        void show();
    }
    /*
    access specifier to private, we get compiler error 
    because a derived class tries to access it.
    */
}
