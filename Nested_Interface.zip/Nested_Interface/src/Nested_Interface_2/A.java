
package Nested_Interface_2;

public class A {
    
    public static void main(String[] args) {
        Test.Yes ob;
       Testing t = new Testing();
       ob = t;
       ob.show();
    }
}
