
package Nested_Interface_3;

public interface Test {
    
    interface Yes{
        void show();
    }
}
