
package Static_KeyWord;

public class Student {
    String name;
    int id;
    static String Univarsity_Name = "Aust";
    
    Student(String n,int i)
    {
        name = n;
        id = i;
        
    }
    void displayInformation()
    {
         System.out.println("Name = "+name);
        System.out.println("Id = "+id);
        System.out.println("Univarsity Name = "+Univarsity_Name);
        System.out.println("\n\n");
    }
}
