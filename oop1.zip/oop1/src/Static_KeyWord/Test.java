
package Static_KeyWord;

public class Test {
    public static void main(String[] args) {
        Student s1 = new Student("Khaled",101);
        s1.displayInformation();
        Student s2 = new Student("Noman",108);
        s2.displayInformation();
        Student s3 = new Student("Palash",113);
        s3.displayInformation();
        Student s4 = new Student("Mehedi",114);
        s4.displayInformation();
        Student s5 = new Student("Tamzid",124);
        s5.displayInformation();
    }
    
            
}
