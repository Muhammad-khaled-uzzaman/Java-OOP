
package StaticVariable;

public class Test {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.totalStudent();
        
        Student s2 = new Student();
        s2.totalStudent();
        
        Student s3 = new Student();
        s3.totalStudent();
        
        Student s4 = new Student();
        s4.totalStudent();
        
        Student s5 = new Student();
        s5.totalStudent();
    }
}
