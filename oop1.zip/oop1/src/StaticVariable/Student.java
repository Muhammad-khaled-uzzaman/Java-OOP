
package StaticVariable;

public class Student {
    //int count=0; non static variable
    static int count =0;
    Student()
    {
        count++;
    }
    void totalStudent()
    {
        System.out.println("Total Student = "+count);
    }
}
