
package oop1;

public class TeacherDemo {
    String name,gender;
    int phone;
    
    TeacherDemo()
    {
        System.out.println("No value");
    }
    
    
   TeacherDemo(String n,String g,int ph)
   {
       name = n;
       gender = g;
       phone = ph;
   }
    void displayInformation()
    {
         System.out.println("Name = "+name);
        System.out.println("Gander = "+gender);
        System.out.println("Phone = "+phone);
        System.out.println();
        
    }
}
