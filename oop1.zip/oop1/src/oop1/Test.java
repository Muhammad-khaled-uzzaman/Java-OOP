
package oop1;

public class Test {
    public static void main(String[] args) {
        TeacherDemo teacher1 = new TeacherDemo("Muhammad Khaleduzzaman","Male",152431037);
        teacher1.displayInformation();
        
         TeacherDemo teacher2 = new TeacherDemo("Ritu","Female",172431037);
         teacher2.displayInformation();
         
         TeacherDemo teacher3 = new TeacherDemo();
         teacher3.displayInformation();
        
    } 
}
