
package Static_variable;

public class StaticVariable {
    static String UnivarsityName = "Aust";
}
