
package Static_variable;

public class Test {
    public static void main(String[] args) {
        //StaticVariable ob = new StaticVariable();
        //ob.UnivarsityName
        System.out.println("Univarsity Name = "+StaticVariable.UnivarsityName);
    }
}
