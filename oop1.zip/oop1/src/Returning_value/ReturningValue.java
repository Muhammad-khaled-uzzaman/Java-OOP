
package Returning_value;

public class ReturningValue {
    int square(int value)
    {
        return value*value;
    }
}
