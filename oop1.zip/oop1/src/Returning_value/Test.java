
package Returning_value;

public class Test {
    public static void main(String[] args) {
        ReturningValue ob1 = new ReturningValue();
        int result = ob1.square(5);
        System.out.println("Square of 5 = "+result);
        
        ReturningValue ob2 = new ReturningValue();
        result = ob1.square(6);
        System.out.println("Square of 5 = "+result);
       
    }
}
