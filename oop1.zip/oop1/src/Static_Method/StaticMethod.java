
package Static_Method;

public class StaticMethod {
    void display1()
    {
        System.out.println("I am non static method");
    }
    
    static void display2()
    {
        System.out.println("I am static method");
    }
}
