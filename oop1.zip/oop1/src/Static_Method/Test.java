
package Static_Method;

public class Test {
    public static void main(String[] args) {
            StaticMethod ob = new StaticMethod();
            ob.display1();
            
            StaticMethod.display2();
    }
}
