
package OverLoding_Constructor;

public class OverlodingConstructor {
    public static void main(String[] args) {
          Teacher teacher1 = new Teacher();
          teacher1.displayInformation();
          
          Teacher teacher2 = new Teacher("Muhammad Khaleduzzaman","Male");
          teacher2.displayInformation();
          
          Teacher teacher3 = new Teacher("Lisa","Female",1521431037);
          teacher3.displayInformation();
          
          
    }
}
