
package Example2;

public class Base {
    private void  foo(){
        System.out.println("Parent");
    }
}
