
package Example2;

public class Derived extends Base {
    
    public void foo(){
        System.out.println("Child");
    }
}
