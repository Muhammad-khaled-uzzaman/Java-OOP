/*
Invoking overridden method from sub-class
*/
// A Java program to demonstrate that overridden  
// method can be called from sub-class 
package GeeksforGeeksExample5;

public class Parent {
    
    void show(){
        System.out.println("Parent's show()");
    }
}
