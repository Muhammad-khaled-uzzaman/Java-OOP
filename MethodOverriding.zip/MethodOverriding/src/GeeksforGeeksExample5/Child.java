
package GeeksforGeeksExample5;

public class Child extends Parent {
    
    @Override
    void show(){
       
        System.out.println("Child's show()");
        super.show();
    }
}
