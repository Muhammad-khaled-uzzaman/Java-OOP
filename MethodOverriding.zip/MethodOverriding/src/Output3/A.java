/*
The overriding method can not have more restrictive access modifier.
*/
package Output3;

public class A {
    
    public void getDetails(){
        System.out.println("A class");
    }
}
