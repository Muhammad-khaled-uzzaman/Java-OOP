
package Output3;

public class B extends A {
    /*
    protected void getDetails(){             //Compilation error due to access modifier
        System.out.println("B class");
    }
*/
}
