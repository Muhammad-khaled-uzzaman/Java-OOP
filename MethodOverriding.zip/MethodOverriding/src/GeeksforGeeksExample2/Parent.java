package GeeksforGeeksExample2;

public class Parent {

    private void m1() {
        System.out.println("From parent m1()");
    }

    protected void m2() {

        System.out.println("From parent m2()");

    }
}
