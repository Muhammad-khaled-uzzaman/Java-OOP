
package GeeksforGeeksExample2;

public class Main {
   
    public static void main(String[] args) {
        Parent ob = new Parent();
        ob.m2();
        
        Child obj = new Child();
        obj.m2();
        
    }
}
