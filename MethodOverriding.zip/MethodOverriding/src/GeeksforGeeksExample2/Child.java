
package GeeksforGeeksExample2;

public class Child extends Parent {
    
     private void m1(){
        System.out.println("From child m1()");
    }
    
     @Override
    protected void m2(){
        System.out.println("From child m2()");
    }
}
