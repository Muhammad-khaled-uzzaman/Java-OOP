
package Example1;

public class Derived extends Test {
    
    public void foo(){
        System.out.println("Child");
    }
}
