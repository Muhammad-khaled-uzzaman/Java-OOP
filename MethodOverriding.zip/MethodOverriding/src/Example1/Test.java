
package Example1;

public class Test {
    
    private final void foo(){
        System.out.println("Parent");
    }

}
