
package GeeksforGeeksExample7;

public class Child1 extends Parent {
    
    @Override
    void m1() throws RuntimeException{
        System.out.println("From child2 m1()");
    }
}
