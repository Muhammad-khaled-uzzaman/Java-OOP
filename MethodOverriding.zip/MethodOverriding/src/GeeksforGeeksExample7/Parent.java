/* Java program to demonstrate overriding when  
  superclass method does declare an exception 
*/
package GeeksforGeeksExample7;

public class Parent {

    void m1() throws RuntimeException {
        System.out.println("From parent m1()");
    }
}
