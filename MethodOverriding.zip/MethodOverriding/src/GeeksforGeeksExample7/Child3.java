
package GeeksforGeeksExample7;

public class Child3 extends Parent {
    
    @Override
    void m1(){
        System.out.println("From child3 m1()");
    }
}
