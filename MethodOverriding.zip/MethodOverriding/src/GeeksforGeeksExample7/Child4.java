
package GeeksforGeeksExample7;

public class Child4 extends Parent {
    
    /*
    //compile-time error 
    // issue while throwing parent exception
    @Override
    void m1() throws Exception{
        System.out.println("");
    }
*/
}
