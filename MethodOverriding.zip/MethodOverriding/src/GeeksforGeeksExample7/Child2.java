
package GeeksforGeeksExample7;

public class Child2 extends Parent {
    
    @Override
    void m1() throws ArithmeticException{
        System.out.println("From child2 m1()");
    }
}
