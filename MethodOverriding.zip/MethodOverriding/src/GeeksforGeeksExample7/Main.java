
package GeeksforGeeksExample7;

public class Main {
    
    public static void main(String[] args) {
        
        Child4 c = new Child4();
        c.m1();
    }
}
