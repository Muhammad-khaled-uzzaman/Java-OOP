
package Output4;

public class B extends A{
    /*
    @Override
    public void getDetails() throws Exception   //Compilation error
    { 
        System.out.println("B class"); 
    } 
*/

}
