/*
The exception thrown by the overriding method should not 
be new or more broader checked exception
*/

package Output4;

import java.io.IOException;

public class A {

    public void getDetails() throws IOException //line 23 
    {
        System.out.println("A class");
    }
}
