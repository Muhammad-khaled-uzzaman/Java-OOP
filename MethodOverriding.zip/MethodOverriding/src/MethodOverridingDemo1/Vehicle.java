
package MethodOverridingDemo1;

public class Vehicle {
    
    void run()
    {
        System.out.println("Vehicle is running");
    }
}
