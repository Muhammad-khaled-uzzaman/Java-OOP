
package MethodOverridingDemo1;

public class Bike extends Vehicle {
    public static void main(String[] args) {
        
        Bike ob = new Bike();
        ob.run();
    }
}
