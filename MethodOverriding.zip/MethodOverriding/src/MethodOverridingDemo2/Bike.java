
package MethodOverridingDemo2;

public class Bike extends Vehicle {
    
    @Override
    void run()
    {
        System.out.println("Bike is running safely");
    }
}
