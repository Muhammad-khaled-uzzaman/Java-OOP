
package MethodOverridingDemo2;

public class Vehicle {
    
    void run()
    {
        System.out.println("Vehicle is running");
    }
}
