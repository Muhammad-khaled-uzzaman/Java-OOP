package MethodOverridingDemo2;

public class Test {
    public static void main(String[] args) {
        
        Bike ob = new Bike();
        ob.run();
    }
}
