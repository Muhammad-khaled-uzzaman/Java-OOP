package GeeksforGeeksExample4;

public class Main {
    
    public static void main(String[] args) {
        Parent ob = new Child();
        
        // As per overriding rules this should call to class Child static  
        // overridden method. Since static method can not be overridden, it  
        // calls Parent's m1()  
        ob.m1();
        
        ob.m2();
        
    }
}
