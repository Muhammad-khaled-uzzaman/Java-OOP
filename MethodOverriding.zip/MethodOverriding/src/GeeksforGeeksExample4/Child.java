
package GeeksforGeeksExample4;

public class Child extends Parent {
    // This method hides m1() in Parent 
    static void m1(){
        System.out.println("From child static m1()");
    }
    
    @Override
    public void m2(){
        System.out.println("From child non-static(instance) m2()");
    }
}
