/*
Static methods can not be overridden(Method Overriding vs Method Hiding)
*/
/* Java program to show that if static method is redefined by 
a derived class, then it is not overriding,it is hiding */
  
package GeeksforGeeksExample4;

public class Parent {
    // Static method in base class which will be hidden in subclass  
    static void m1(){
        System.out.println("From parent static m1()");
    }
    // Non-static method which will be overridden in derived class  
    public void m2(){
        System.out.println("From parent non-static(instance) m2()");
    }
}
