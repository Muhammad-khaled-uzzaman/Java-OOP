
package GeeksforGeeksExample3;

public class Parent {
    
    final void show(){
        
    }
}
