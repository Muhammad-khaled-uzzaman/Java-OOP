
package GeeksforGeeksExample3;

public class Child extends Parent {
    // Can't be overridden 
  /*  final void show(){
        
    }
*/
    
    public static void main(String[] args) {
        Child c = new Child();
        c.show();
    }
}
