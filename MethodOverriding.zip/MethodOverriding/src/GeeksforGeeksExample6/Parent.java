/*
Overriding and Exception-Handling
*/
package GeeksforGeeksExample6;

public class Parent {
    
    void m1(){
        System.out.println("From parent m1()");
    }
    
    void m2(){
        System.out.println("From parent  m2()");
    }
}
