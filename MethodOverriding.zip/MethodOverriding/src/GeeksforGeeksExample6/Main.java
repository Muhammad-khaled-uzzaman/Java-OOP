
package GeeksforGeeksExample6;

public class Main {
    
    public static void main(String[] args) {
        Child ob = new Child();
        ob.m1();
        ob.m2();
    }
}
