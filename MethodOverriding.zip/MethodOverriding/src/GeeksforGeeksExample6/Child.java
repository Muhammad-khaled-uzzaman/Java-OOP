
package GeeksforGeeksExample6;

public class Child extends Parent {
    
    @Override
    // no issue while throwing unchecked exception 
    void m1() throws ArithmeticException{
        System.out.println("From child m1()");
    } 
    // compile-time error 
    // issue while throwin checked exception 
    /*
    @Override
    void m2() throws Exception{
        System.out.println("From child m2");
    }
*/
}
