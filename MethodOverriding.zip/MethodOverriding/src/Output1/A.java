/*
 Final and static methods cannot be overridden
*/
package Output1;

public class A {
    
    protected final void getDetails(){
        System.out.println("A class");
    }
}
