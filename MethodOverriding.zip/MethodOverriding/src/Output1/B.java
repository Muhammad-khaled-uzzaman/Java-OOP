
package Output1;

public class B extends A {
    /*
    @Override
    protected final void getDetails(){         //Compilation error
        System.out.println("B class");
    }
*/
    public static void main(String[] args) {
        B b = new B();
        b.getDetails();
        
    }
}
