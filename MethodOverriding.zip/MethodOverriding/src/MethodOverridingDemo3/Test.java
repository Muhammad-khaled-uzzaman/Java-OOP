
package MethodOverridingDemo3;

public class Test {
    
    public static void main(String[] args) {
        
        SBI sb = new SBI();
        System.out.println("SBI Rate of Interest : "+sb.getRateOfInterest());
        ICICI ic = new ICICI();
        System.out.println("ICICI Rate of Interest : "+ic.getRateOfInterest());
        AXIS ax = new AXIS();
        System.out.println("AXIS Rate of Interest : "+ax.getRateOfInterest());
    }
}
