
package MethodOverridingDemo3;

public class AXIS extends Bank {
    
    @Override
    int getRateOfInterest()
    {
        return 9;
    }
}
