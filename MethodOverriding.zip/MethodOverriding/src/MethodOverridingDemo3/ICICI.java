
package MethodOverridingDemo3;

public class ICICI extends Bank {
    
    @Override
    int getRateOfInterest()
    {
        return 7;
    }
}
