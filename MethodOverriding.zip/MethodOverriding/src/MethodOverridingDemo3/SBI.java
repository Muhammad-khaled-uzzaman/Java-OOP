
package MethodOverridingDemo3;

public class SBI extends Bank {
    
    @Override
    int getRateOfInterest()
    {
        return 8;
    }
}
