
package MethodOverridingDemo3;

public class Bank {
    int getRateOfInterest()
    {
        return 0;
    }
}
