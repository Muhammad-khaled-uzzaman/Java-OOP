
package GeeksforGeeksExample1;

public class Parent {
    
    void show(){
        System.out.println("Parent's show()");
    }
}
