
package Output2;

public class B extends A {
    /*
    public int getDetails(String temp){
        System.out.println("B class : "+temp);  //Compilation error
        return o;
    }
*/
}
