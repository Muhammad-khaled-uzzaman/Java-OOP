/*
The overriding method must have same signature
*/
package Output2;

public class A {
    
    public void getDetails(String temp){
        System.out.println("A class : "+temp);
    }
}
