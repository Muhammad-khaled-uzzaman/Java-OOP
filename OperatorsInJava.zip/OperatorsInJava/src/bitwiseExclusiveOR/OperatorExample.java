
package bitwiseExclusiveOR;

public class OperatorExample {
    public static void main(String[] args) {
        
         int a = 10;
         int b = 5;
         int c = 20;
         int d =30;
         
         System.out.println(a>b^a<c);//false
         System.out.println(a<b^a<c);//true
         System.out.println(a>b^a<c^b<c);//ture
         System.out.println(a>b^a<c^b<c^a<d);//false
         
    }
}
