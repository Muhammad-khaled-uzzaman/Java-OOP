/*
Java Arithmetic Operator Example: Expression
*/
package arithmeticOperators;

public class OperatorExample {
    
    public static void main(String[] args) {
        
        System.out.println(10*10/5+3-1*4/2); 
        /*
        10*10/5+3-1*4/2
        10*2+3-1*2
        20+3-2
        20+1
        21
        */
    }
}
