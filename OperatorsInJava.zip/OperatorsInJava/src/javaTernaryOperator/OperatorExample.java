/*
Java Ternary Operator

Java Ternary operator is used as one liner replacement for if-then-else statement 
and used a lot in java programming. it is the only conditional operator which takes three operands.
*/
package javaTernaryOperator;

public class OperatorExample {
    
    public static void main(String[] args) {
        
        int a = 2;
        int b = 5;
        
        int min=(a<b)?a:b;
        System.out.println(min);
    }
}
