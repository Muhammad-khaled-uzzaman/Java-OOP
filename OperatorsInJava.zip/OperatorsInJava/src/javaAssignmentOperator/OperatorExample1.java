/*
Java Assignment Operator
Java assignment operator is one of the most common operator. 
It is used to assign the value on its right to the operand on its left.

Java Assignment Operator Example
 */
package javaAssignmentOperator;

public class OperatorExample1 {

    public static void main(String[] args) {

        int a = 10;
        int b = 20;

        a += 4;
        b -= 4;
        System.out.println(a);
        System.out.println(b);

    }
}
