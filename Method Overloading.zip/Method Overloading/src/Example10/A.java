/*
But boxing followed by widening is acceptable if this is passed to a reference of type Object. 
See the following example for this.
*/
package Example10;

public class A {
    
    // overloaded method with refernce type 
    // formal argument 
    public void method(Object b){
        
        // Object b is typecasted to Byte and then printed  
        Byte bt = (Byte) b;
        System.out.println("refernce type formal argument : "+bt);
    }
}
