
package Example10;

public class B {
    public static void main(String[] args) {
        A a = new A();
        
        byte val = 5;
        // b is first widened to Byte  
        // and then Byte is passed to Object.
        a.method(val);
    }
}
