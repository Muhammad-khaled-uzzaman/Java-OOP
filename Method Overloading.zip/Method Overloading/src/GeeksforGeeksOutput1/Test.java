
package GeeksforGeeksOutput1;

public class Test {
    
    public int getData(String temp){
        return 0;
    }
   /* 
    public int getData(String temp){  //methods must have different signatures
        return 1;
    }
*/
    
    public static void main(String[] args) {
        Test ob = new Test();
        System.out.println(ob.getData("GFG"));
    }
}
