/*
In this example, we have created two methods that differs in data type. 
The first add method receives two integer arguments and 
second add method receives two double arguments.
*/
package MethodOverloadingDemo2;

public class Adder {
    
    static int add(int a,int b)
    {
        return a+b;
    }
    static double add(double a,double b)
    {
        return a+b;
    }
}
