/*
changing the Order of the parameters
*/
package Example3;

public class Test {
    
    public void geekIdentity(String name,int id){
        System.out.println("Name : "+name+" "+"Id : "+id);
    }
    
    public void geekIdentity(int id,String name){
        System.out.println("Name : "+name+" "+"Id : "+id);
    }
    public static void main(String[] args) {
        Test ob = new Test();
        ob.geekIdentity("Muhammad", 02);
        ob.geekIdentity(01, "Masum");
    }
}
