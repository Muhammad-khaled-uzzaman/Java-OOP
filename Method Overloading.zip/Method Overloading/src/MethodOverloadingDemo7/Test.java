
package MethodOverloadingDemo7;

public class Test {
    public static void main(String[] args) {
        
        Adder ob = new Adder();
        System.out.println(ob.add(10, 20));
        System.out.println(ob.add(10, 20, 10));
    }
}
