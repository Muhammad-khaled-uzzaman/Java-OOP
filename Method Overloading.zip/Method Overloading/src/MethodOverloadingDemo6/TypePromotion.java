/*
If there are no matching type arguments in the method, 
and each method promotes similar number of arguments, there will be ambiguity.
*/
package MethodOverloadingDemo6;

public class TypePromotion {
    
    void sum(int a,long b)
    {
        System.out.println(a+b);
    }
    void sum(long a,int b)
    {
        System.out.println(a+b);
    }
    public static void main(String[] args) {
        
        TypePromotion ob = new TypePromotion();
        //ob.sum(20,20 );ambiguity
    }
}
