
package Example7;

public class Test {

    public static void main(String[] args) {
        Conversion c = new Conversion();

        c.method(10);
        c.method(new Integer(100));
        c.method(new Long(10));

    }
}
