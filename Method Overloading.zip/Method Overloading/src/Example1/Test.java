package Example1;

public class Test {

    public static void main(String[] args) {
        Addition ob = new Addition();
        int sum1 = ob.add(50, 100);
        int sum2 = ob.add(100, 100, 100);
        System.out.println("sum of the two integer value : "+sum1);
        System.out.println("sum of the three integer value :"+sum2);
    }
}
