package Example2;

public class Test {

    public static void main(String[] args) {
        Addition ob = new Addition();
        int sum1 = ob.add(100, 100);
        System.out.println("sum of the two integer value :" + sum1);
        double sum2 = ob.add(10.5, 10.20, 10.30);
        System.out.println("sum of the three double value : " + sum2);
    }
}
