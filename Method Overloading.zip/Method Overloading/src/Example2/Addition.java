/*
changing the Data types of the parameters
*/
package Example2;

public class Addition {
    
    public int add(int a,int b){
        int sum = a+b;
        return sum;
    }
    public double add(double a,double b,double c){
        double sum = a+b+c;
        return sum;
    }
}
