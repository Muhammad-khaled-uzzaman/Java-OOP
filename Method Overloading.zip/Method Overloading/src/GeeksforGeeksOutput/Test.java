
package GeeksforGeeksOutput;

public class Test {
    
    public int getData(){
        return 0;
    }
    
    public long getData(int a){//methods must have different signatures
        return 1;
    }
    
    public static void main(String[] args) {
        Test ob = new Test();
        System.out.println(ob.getData());
        System.out.println(ob.getData(1));
    }
}
