package Example8;

public class Test {

    public static void main(String[] args) {
        Conversion c = new Conversion();
        // invoking the method with signature 
        // has widened data type 
        c.method(10);
        c.method(new Long(100));

    }
}
