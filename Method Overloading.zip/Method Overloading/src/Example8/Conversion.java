/*
Method Overloading with Widening
 */
// Java program to illustrate method  
// overloading  
// in case of widening 
package Example8;

public class Conversion {

    public void method(int i) {
        System.out.println("Primitive type int formal argument : " + i);
    }

    // overloaded method primitive formal argument 
    // and to be invoked for wrapper Object as  
    public void method(float f) {
        System.out.println("Primitive type float formal argument : " + f);
    }
}
