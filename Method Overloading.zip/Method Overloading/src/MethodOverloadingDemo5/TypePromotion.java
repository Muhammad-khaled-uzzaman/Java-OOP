/*If there are matching type arguments in the method, 
type promotion is not performed.
*/
package MethodOverloadingDemo5;

public class TypePromotion {
    
    void sum(int a,int b)
    {
        System.out.println("int arg method invoked");
    }
    void sum(long a,long b)
    {
        System.out.println("long arg method invoked");
    }
    
    public static void main(String[] args) {
        
        TypePromotion ob = new TypePromotion();
        
        ob.sum(20, 20);//now int arg sum() method gets invoked
    }
}
