
package GeeksforGeeksOutput4;

public class Test {
    
    private String function(String temp,int data){
        return ("GFG");
    }
    
    private String function(int datam,String temp){
        return ("GeeksforGeeks");
    }
    
    public static void main(String[] args) {
        Test ob = new Test();
        System.out.println(ob.function(4, "GFG"));
    }
}
