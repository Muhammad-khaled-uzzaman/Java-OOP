
package MethodOverloadingDemo1;

public class Test {
    public static void main(String[] args) {
        /*
        //Adder ob = new Adder();
        In this example, we are creating static methods so that we don't need 
        to create instance for calling methods.
        */
        
        System.out.println(Adder.add(10, 10));
        System.out.println(Adder.add(10, 5, 5));
    }
}
