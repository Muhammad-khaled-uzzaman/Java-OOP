//In this example, we have created two methods, first add() method performs 
//addition of two numbers and second add method performs addition of three numbers....
package MethodOverloadingDemo1;

public class Adder {
    
    static int add(int x,int y)
    {
        return x+y;
    }
    
    static int add(int x,int y,int z)
    {
        return x+y+z;
    }
}
