
package GeeksforGeeksOutput2;

public class Test {
    
    private String function(){
        return ("GFG");
    }
    
    public final static String function(int data){
        return ("GeeksforGeeks");
    }
    
    public static void main(String[] args) {
        Test ob = new Test();
        System.out.println(ob.function());
    }
}
