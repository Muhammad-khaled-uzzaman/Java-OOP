/*
Method Overloading with Var-args argument

Widening of primitive type gets more priority over var-args
*/
package Example11;

public class Conversion {
    
    public void method(byte ...a){
        System.out.println("Primitive type byte formal argument : "+a);
    }
    public void method(long a,long b){
        System.out.println("Widening type long formal argument : "+a);
    }
}
