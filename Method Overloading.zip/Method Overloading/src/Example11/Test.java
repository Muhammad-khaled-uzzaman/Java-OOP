
package Example11;

public class Test {
    public static void main(String[] args) {
        
        Conversion c = new Conversion();
         
        // invokes the method having widening  
        // primitive type parameters. 
        byte val = 5;
        c.method(val, val);
    }
}
