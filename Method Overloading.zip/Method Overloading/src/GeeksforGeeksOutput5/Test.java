
package GeeksforGeeksOutput5;

public class Test {
    private String function(String temp,int data,int sum){
        return("GFG");
    }
    
    private String function(String temp,int data){
        return ("GeeksforGeeks");
    }
    
    public static void main(String[] args) {
        Test ob = new Test();
        System.out.println(ob.function("GFG", 10, 220));
    }
}
