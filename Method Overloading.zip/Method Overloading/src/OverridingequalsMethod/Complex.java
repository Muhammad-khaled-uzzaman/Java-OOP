/*
Overriding equals method in Java
*/
package OverridingequalsMethod;

public class Complex {
    
    private double re,im;
    
    public Complex(double re,double im){
        this.re = re;
        this.im = im;
    }
}
