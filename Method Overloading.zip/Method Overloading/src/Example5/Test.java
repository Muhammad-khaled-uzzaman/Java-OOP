/*
Method overloading and null error in Java
 */
package Example5;

public class Test {

    public void fun(Integer i) {
        System.out.println("fun(Integer )");
    }

    public void fun(String name) {
        System.out.println("fun(String )");
    }

    public static void main(String[] args) {
        Test ob = new Test();
        // ob.fun(null);
        /*
        Integer and String both are not primitive data types in Java
       That means they accept null values
         */
    }
}
