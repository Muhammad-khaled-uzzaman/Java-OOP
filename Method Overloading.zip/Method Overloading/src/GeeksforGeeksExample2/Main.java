/*
Overloading methods on return type is possible in cases where data type 
of the function being called is explicitly specified. Look at the examples below :
*/
// Java program to demonstrate working of method 
// overloading in static methods 
package GeeksforGeeksExample2;

public class Main {
    
    public static int foo(int a){
        return 10;
    }
    public static char foo(int a,int b){
        return 'a';
    }
    
    public static void main(String[] args) {
        System.out.println(foo(1));
        System.out.println(foo(1,2));
    }
}
