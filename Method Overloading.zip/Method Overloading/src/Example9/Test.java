
package Example9;

public class Test {
    public static void main(String[] args) {
        Conversion c = new Conversion();
        
        byte val = 5;
        //c.method(val);
    }
}
