// Java program  to illustrate method  
// overloading for widening 
// and autoboxing together 
package Example9;

public class Conversion {
    // overloaded method with refernce type formal argument
    public void method(Integer a){
        System.out.println("Primitive type byte formal argument : "+a);
    }
}
