package Example6;

public class Test {
    
    public void fun(Integer i) {
        System.out.println("fun(Integer) ");
    }

    public void fun(String name) {
        System.out.println("fun(String ) ");
    }

    public static void main(String[] args) {
        Test ob = new Test();
        Integer arg = null;
        ob.fun(arg);
    }
}
