
package oppdemo;

public class opp1 {
    public static void main(String[] args) {
        
    }
}
