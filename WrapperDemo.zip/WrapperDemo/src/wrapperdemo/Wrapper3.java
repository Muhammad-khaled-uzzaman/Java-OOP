
package wrapperdemo;

public class Wrapper3 {
    public static void main(String[] args) {
        String s ="32";
        int i = Integer.parseInt(s);
        System.out.println("i = "+i);
        
        double d = Double.parseDouble(s);
        System.out.println("d = "+d);
        
        int x =Integer.valueOf(s);
        System.out.println("x = "+x);
    }
}
