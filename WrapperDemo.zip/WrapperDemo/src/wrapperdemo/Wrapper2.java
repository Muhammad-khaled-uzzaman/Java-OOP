
package wrapperdemo;

public class Wrapper2 {
    public static void main(String[] args) {
        
        int i = 100;
        String s = Integer.toString(i);
        System.out.println(s);
        
        double k = 100.2;
        String f = Double.toString(k);
        System.out.println(f);
        
        boolean b = true;
        String j = Boolean.toString(b);
        
        
    }
}
