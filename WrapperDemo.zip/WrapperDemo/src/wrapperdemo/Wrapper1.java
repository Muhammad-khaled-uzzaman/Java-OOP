
package wrapperdemo;

public class Wrapper1 {
    public static void main(String[] args) {
        //primitive->object
        
        int x = 30;
        Integer y = Integer.valueOf(x);
        System.out.println("y = "+y);
        
        Integer z = x;
        System.out.println("z = "+z);
        
        //object->primitive
        
        Double d = new Double(12.5);
        System.out.println("d = "+d);
        
        double e = d.doubleValue();
        System.out.println("e = "+e);
        
        double f = d;
        System.out.println("f = "+f);
    }
}
