
package Marker_interface_1;

public class Test {
    
    public static void main(String[] args) throws CloneNotSupportedException  {
        
        A a1 = new A(20,"Java T_Point");
        A a2 =(A)a1.clone();
        
        System.out.println(a1.i);
        System.out.println(a2.s);
    }
}
