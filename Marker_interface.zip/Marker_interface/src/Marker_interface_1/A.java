/*
// Java program to illustrate Cloneable interface 
*/
package Marker_interface_1;
import java.lang.Cloneable; 
public class A implements Cloneable {
    
    int i;
    String s;
    
    public A(int i,String s){
        this.i = i;
        this.s = s;
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
