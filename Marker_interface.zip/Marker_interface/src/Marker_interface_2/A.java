
package Marker_interface_2;

import java.io.Serializable;

public class A implements Serializable {
    
    int i;
    String s;
    
    public A(int i,String s){
        this.i = i;
        this.s = s;
    }
}
