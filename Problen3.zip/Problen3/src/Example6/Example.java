
package Example6;

public class Example implements java.io.Serializable {
    
    public int emp_id;
    public String emp_name;
    
    
    public Example(int emp_id,String emp_name){
        this.emp_id = emp_id;
        this.emp_name = emp_name;
    }
}
