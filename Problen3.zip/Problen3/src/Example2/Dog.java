
package Example2;

public class Dog {
   
    String dogName;
    int dogAge;
    
    Dog(String dogName,int dogAge){
        this.dogName = dogName;
        this.dogAge = dogAge;
    }
}
