
package Example2;

public class Test {
    public static void main(String[] args) {
        Dog ob1 = new Dog("Muhammad",101);
        Dog ob2 = new Dog("Khaled",102);
        
        System.out.println(ob1.dogName+" , "+ob1.dogAge);
        System.out.println(ob2.dogName+" , "+ob2.dogAge);
    }
}
