
package Example5;

public class Test {
    public static void main(String[] args) {
        
        try{
            Employee ob1 = new Employee("khaled",102);
            
            Employee ob2 = (Employee)ob1.Clone();
            System.out.println(ob1.emp_id+" "+ob1.emp_name);
            System.out.println(ob2.emp_id+" "+ob2.emp_name);
        }catch(CloneNotSupportedException c){
            System.out.println("Exception : "+c);
        }
    }
}
