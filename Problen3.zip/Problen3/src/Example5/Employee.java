/*
// java program to demonstrate 
// object creation using clone() method 
  
// employee class whose objects are cloned 
*/
package Example5;

public class Employee implements Cloneable {
    
    int emp_id;
    String emp_name;
    
    Employee(String emp_name,int emp_id){
        this.emp_id = emp_id;
        this.emp_name = emp_name;
    }
    
    public Object Clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
