/*
/ Java program to demostrate 
// object creation using newInstance() method 
*/
package Example3;

public class Example {
    
    void message(){
        System.out.println("Hello Bangladesh !");
    }
}
