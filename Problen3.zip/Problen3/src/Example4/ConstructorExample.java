/*
// java program to demostrate 
// creation of object 
// using Constructor.newInstance() method 
*/
package Example4;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ConstructorExample {
    public static void main(String[] args) 
            throws NoSuchMethodException,
                   SecurityException,
                   InstantiationException,
                   IllegalAccessException,
                   IllegalArgumentException,
                   InvocationTargetException
    {
        Constructor constructor = ExampleClass.class.getConstructor(String.class);
        ExampleClass exampleObject =(ExampleClass)constructor.newInstance("Khaleduzzaman");
        System.out.println(exampleObject.getemp_name());
    }
}
