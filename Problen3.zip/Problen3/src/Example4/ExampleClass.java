/*
Using newInstance() method for Constructor class
*/
package Example4;

public class ExampleClass {
    
    private String emp_name;
    
    public ExampleClass(String emp_name){
        this.emp_name = emp_name;
    }
    
    public String getemp_name(){
        return emp_name;
    }
    
    public void setemp_name(String emp_name){
        this.emp_name = emp_name;
    }
}
