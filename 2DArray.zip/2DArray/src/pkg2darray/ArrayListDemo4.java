
package pkg2darray;

import java.util.ArrayList;

public class ArrayListDemo4 {
    public static void main(String[] args) {
        ArrayList<Integer>number = new ArrayList<Integer>();
        System.out.println("Size "+number.size());
        number.add(10);
        number.add(20);
        number.add(30);
        
        number.add(3,40);
        
        System.out.println("ArrayList Contains  : "+number);
        System.out.println();
        System.out.println("Size "+number.size());
        
        boolean cheak = number.isEmpty();
        
        System.out.println("ArrayList Empty : "+cheak);
        
        boolean contain = number.contains(40);
        System.out.println(" 40 is in the list : "+contain);
        
        int pos = number.indexOf(10);
        
        System.out.println("The index of 10 : "+pos);
        
        number.set(4, 50);
        System.out.println("ArrayList Contains  : "+number);
      
    }
}
