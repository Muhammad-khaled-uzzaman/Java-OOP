
package pkg2darray;

import java.util.ArrayList;

public class ArrayListDemo {
    public static void main(String[] args) {
        ArrayList<Integer>number = new ArrayList<Integer>();
        System.out.println("Size "+number.size());
        number.add(10);
        number.add(20);
        number.add(30);
        
        number.add(3,40);
        
        System.out.println("ArrayList Contains  : "+number);
        System.out.println("Size "+number.size());
        
        //Remove
        
        number.remove(2);
        System.out.println("After Removing ArrayList Contains : "+number);
        
        number.removeAll(number);
         System.out.println("After Removing All ArrayList Contain : "+number);
         
         number.clear();
         System.out.println("After Clear ArrayList Contain : "+number);
         
        
    }
}
