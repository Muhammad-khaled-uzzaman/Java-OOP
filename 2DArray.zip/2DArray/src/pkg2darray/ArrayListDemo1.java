
package pkg2darray;

import java.util.ArrayList;

public class ArrayListDemo1 {
    public static void main(String[] args) {
        ArrayList<Integer>number = new ArrayList<Integer>();
       
        number.add(10);
        number.add(20);
        number.add(30);
        
        number.add(3,40);
        
        for(int x : number)
        {
            System.out.print(" "+x);
        }
    }
    
}
