package ToStringMethod;

public class Complex {

    private double re, im;

    Complex(double re, double im) {
        this.re = re;
        this.im = im;
    }
}
