
package ToStringMethod;

public class Main {
    
    public static void main(String[] args) {
        Complex c1 = new Complex(5,10);
        System.out.println(c1);
    }
}
