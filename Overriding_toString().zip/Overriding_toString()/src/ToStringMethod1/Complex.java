/*
Overriding toString() in Java
 */
package ToStringMethod1;

public class Complex {

    private double re, im;

    public Complex(double re, double im) {
        this.re = re;
        this.im = im;
    }

    @Override
    public String toString() {
        return String.format(re + " + i" + im);
    }
}
