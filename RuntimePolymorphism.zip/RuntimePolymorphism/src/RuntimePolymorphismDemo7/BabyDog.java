
package RuntimePolymorphismDemo7;

public class BabyDog extends Dog {
    
    public static void main(String[] args) {
        
        Animal a = new Dog();
        a.eat();
    }
}
