
package RuntimePolymorphismDemo7;

public class Animal {
    
    void eat()
    {
        System.out.println("animal is eatinng");
    }
}
