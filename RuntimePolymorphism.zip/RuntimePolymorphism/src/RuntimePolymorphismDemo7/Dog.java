
package RuntimePolymorphismDemo7;

public class Dog extends Animal {
    
    @Override
    void eat()
    {
        System.out.println("dog is eating");
    }
}
