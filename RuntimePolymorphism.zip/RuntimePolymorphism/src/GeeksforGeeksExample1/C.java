
package GeeksforGeeksExample1;

public class C extends A {
    
    @Override
    void m1(){
        System.out.println("Inside C's m1 method");
    }
}
