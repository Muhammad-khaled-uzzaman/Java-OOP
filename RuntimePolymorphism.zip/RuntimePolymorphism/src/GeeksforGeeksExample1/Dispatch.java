
package GeeksforGeeksExample1;

public class Dispatch {
    
    public static void main(String[] args) {
        
        A a = new A();
        
        B b = new B();
        
        C c = new C();
        
        A ref;
        
        ref = a;
        
        a.m1();
        
        ref = b;
        
        ref.m1();
        
        ref = c;
        
        ref.m1();
    }
}
