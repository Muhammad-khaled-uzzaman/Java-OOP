
package GeeksforGeeksExample1;

public class B extends A {
    
    @Override
    void m1(){
        System.out.println("Inside B's m1 method");
    }
}
