
package GeeksforGeeksExample1;

public class A {
    
    void m1(){
        System.out.println("Inside A's m1 method");
    }
}
