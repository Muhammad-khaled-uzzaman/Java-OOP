
package RuntimepolymorphismDemo3;

public class Shape {
   
    void draw()
    {
        System.out.println("drawing");
    }
              
}
