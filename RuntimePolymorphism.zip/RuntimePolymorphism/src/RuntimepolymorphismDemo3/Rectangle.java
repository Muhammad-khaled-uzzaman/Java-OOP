
package RuntimepolymorphismDemo3;

public class Rectangle extends Shape {
    
    @Override
    void draw()
    {
        System.out.println("drawing rectangle");
    }
}
