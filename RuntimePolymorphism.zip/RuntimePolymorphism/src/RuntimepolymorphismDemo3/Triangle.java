
package RuntimepolymorphismDemo3;

public class Triangle extends Shape {
    
    @Override
    void draw()
    {
        System.out.println("drawing triangle");
    }
            
}
