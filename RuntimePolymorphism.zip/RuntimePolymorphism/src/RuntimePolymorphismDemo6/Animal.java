/*
Let's see the simple example of Runtime Polymorphism with multilevel inheritance.
*/
package RuntimePolymorphismDemo6;

public class Animal {
    
    void eat()
    {
        System.out.println("eating");
    }
}
