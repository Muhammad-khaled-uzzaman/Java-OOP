
package RuntimePolymorphismDemo6;

public class Dog extends Animal {
    
    @Override
    void eat()
    {
        System.out.println("eating fruit");
    }
}
