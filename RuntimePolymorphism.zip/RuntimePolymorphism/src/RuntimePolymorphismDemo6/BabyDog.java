
package RuntimePolymorphismDemo6;

public class BabyDog extends Dog {
    
    @Override
    void eat()
    {
        System.out.println("drinking milk");
    }
    
    public static void main(String[] args) {
        
        Animal a1,a2,a3;
        
        a1 = new Animal();
        a1.eat();
        
        a2 = new Dog();
        a2.eat();
        
        a3 = new BabyDog();
        a3.eat();
        
    }
}
