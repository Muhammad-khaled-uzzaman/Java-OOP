
package RuntimePolymorphismDemo2;

public class SBI extends Bank{
    
    @Override
    float getRateOfInterest()
    {
        return 8.4f;
    }
}
