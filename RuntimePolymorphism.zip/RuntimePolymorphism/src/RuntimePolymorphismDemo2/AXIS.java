
package RuntimePolymorphismDemo2;

public class AXIS extends Bank {
    
    @Override
    float getRateOfInterest()
    {
        return 9.7f;
    }
}
