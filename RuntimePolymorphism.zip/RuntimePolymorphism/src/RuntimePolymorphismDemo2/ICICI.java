
package RuntimePolymorphismDemo2;

public class ICICI extends Bank {
    
    @Override
    float getRateOfInterest()
    {
        return 7.3f;
    }
    
}
