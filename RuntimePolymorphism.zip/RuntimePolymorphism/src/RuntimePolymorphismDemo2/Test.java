
package RuntimePolymorphismDemo2;

public class Test {
    public static void main(String[] args) {
        
        Bank b ;
        b = new SBI();
        System.out.println("SBI Rateof Interest : "+b.getRateOfInterest()+"%");
        b = new ICICI();
        System.out.println("ICICI Rate of Interest : "+b.getRateOfInterest()+"%");
        b = new AXIS();
        System.out.println("AXIS Rate of Intetest : "+b.getRateOfInterest()+"%");
      
        
        
        
    }
}
