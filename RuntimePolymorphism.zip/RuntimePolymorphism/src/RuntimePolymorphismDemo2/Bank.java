/*
Consider a scenario where Bank is a class that provides a method to get the rate of interest. 
However, the rate of interest may differ according to banks. 
For example, SBI, ICICI, and AXIS banks are providing 8.4%, 7.3%, and 9.7% rate of interest.
*/
package RuntimePolymorphismDemo2;

public class Bank {
    
    float getRateOfInterest()
    {
        return 0;
    }
}
