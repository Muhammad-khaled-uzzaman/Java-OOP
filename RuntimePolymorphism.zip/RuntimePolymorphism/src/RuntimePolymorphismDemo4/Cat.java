
package RuntimePolymorphismDemo4;

public class Cat extends Animal {
    
    @Override
    void eat()
    {
        System.out.println("eating rat");
    }
}
