
package RuntimePolymorphismDemo4;

public class Dog extends Animal {
    
    @Override
    void eat()
    {
        System.out.println("eating bread");
    }
    
}
