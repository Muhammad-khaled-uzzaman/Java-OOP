
package RuntimePolymorphismDemo4;

public class Lion extends Animal {
    
    @Override
    void eat()
    {
        System.out.println("eating meat");
    }
}
