//Java Runtime Polymorphism Example: Animal
package RuntimePolymorphismDemo4;

public class Animal {
    
    void eat()
    {
        System.out.println("eating");
    }
}
