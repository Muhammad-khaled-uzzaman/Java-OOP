
package GeeksforGeeksExample2;

public class A {
    
    int x = 10;
}
