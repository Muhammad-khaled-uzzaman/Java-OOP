
package GeeksforGeeksExample2;

public class B extends A  {
    
    int x = 20;  /*
    Since variables are not overridden, so the statement “a.x” 
    will always refer to data member of super class.
    */
}
