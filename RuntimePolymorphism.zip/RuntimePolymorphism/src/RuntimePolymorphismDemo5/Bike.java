/*
both the classes have a data member speedlimit. 
We are accessing the data member by the reference variable of Parent class which 
refers to the subclass object. Since we are accessing the data member which is not overridden, 
hence it will access the data member of the Parent class always.
*/
package RuntimePolymorphismDemo5;

public class Bike {
    
    int speedlimit = 90;
    
}
