package multipleInheritance2;

public class Parent1 extends GrandParent {

    @Override
    void fun() {
        super.fun();
        System.out.println("Parent1");
    }
}
