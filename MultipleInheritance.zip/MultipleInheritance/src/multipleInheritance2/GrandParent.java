package multipleInheritance2;

public class GrandParent {

    void fun() {
        System.out.println("GrandParent");
    }
}
