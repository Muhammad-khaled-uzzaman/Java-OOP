package multipleInheritance2;

public class Parent2 extends GrandParent {

    @Override
    void fun() {
        System.out.println("Parent2");

    }
}
