
package multipleInheritance;

public class Parent2 {
    void fun(){
        System.out.println("Parent2");
    }
}
