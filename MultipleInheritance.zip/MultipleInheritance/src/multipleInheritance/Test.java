
package multipleInheritance;

public class Test extends Parent1/* ,Parent2 */ {//Compiler Error
    public static void main(String[] args) {
        Test t = new Test();
        t.fun();
    }
}
