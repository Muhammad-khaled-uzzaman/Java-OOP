/*
Java doesn’t support Multiple Inheritance
 */
package multipleInheritance;

public class Parent1 {

    void fun() {
        System.out.println("Parent1");
    }
}
