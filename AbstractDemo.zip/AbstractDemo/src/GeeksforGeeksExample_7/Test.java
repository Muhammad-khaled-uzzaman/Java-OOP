
package GeeksforGeeksExample_7;

public class Test {
    
    public static void main(String[] args) {
        Shape r= new Rectangle(1,2,"Rectangle");
        System.out.println("Area of rectangle: "+r.area());
        r.moveTo(5,5);
        
        System.out.println(" ");
        
        Shape c = new Circle(2,"Circle");
        System.out.println("Area of circle: "+c.area());
        c.moveTo(4, 5);
    }
}
