
package GeeksforGeeksExample_7;

public class Circle extends Shape {
    
    double pi = 3.1416;
    
    int radius;
    
    Circle(int radius,String name){
        super(name);
        this.radius = radius;
    }
    
    @Override
    public void draw(){
        System.out.println("Circle has been drawn ");
    }
    
    @Override
    public double area(){
        return(double)((radius*radius*pi)/2);
    }

}
