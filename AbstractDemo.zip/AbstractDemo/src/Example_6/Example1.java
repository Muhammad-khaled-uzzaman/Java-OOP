
package Example_6;

public interface Example1 {
    int num = 10;
    
}
