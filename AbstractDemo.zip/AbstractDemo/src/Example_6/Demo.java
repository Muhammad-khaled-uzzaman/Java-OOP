
package Example_6;

public class Demo {
    
    public static void main(String[] args) {
        Exampple2 ob = new Exampple2();
        ob.display();
    }
}
