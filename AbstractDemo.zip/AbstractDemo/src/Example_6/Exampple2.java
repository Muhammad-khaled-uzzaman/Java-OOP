
package Example_6;

public class Exampple2 implements Example1 {
    public void display(){
        System.out.println("Num1 : "+num);
    }
}
