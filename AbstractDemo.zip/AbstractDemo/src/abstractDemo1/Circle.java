
package abstractDemo1;

public class Circle extends Shape {
    
    @Override
    void draw()
    {
        System.out.println("drawin circle");
    }
}
