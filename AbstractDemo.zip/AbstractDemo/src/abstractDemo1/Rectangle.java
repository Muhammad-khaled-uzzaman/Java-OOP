
package abstractDemo1;

public class Rectangle extends Shape {
    
    @Override
    void draw()
    {
        System.out.println("drawing rectangle");
    }
}
