
package abstractDemo1;

public class Test {
    public static void main(String[] args) {
        
        Shape ob;
        ob = new Rectangle();
        ob.draw();
        
        ob = new Circle();
        ob.draw();
    }
}
