/*
In this example, Shape is the abstract class, and its implementation is provided by 
the Rectangle and Circle classes.Mostly, we don't know about the implementation class 
 (which is hidden to the end user), and an object of the implementation class 
is provided by the factory method
*/

package abstractDemo1;

public abstract class Shape {
    
    abstract void draw();
}
