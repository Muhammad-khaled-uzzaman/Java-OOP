
package abstractDemo2;

public class SBI extends Bank {
    
    @Override
    int getRateOfInterest()
    {
       return 7; 
    }
}
