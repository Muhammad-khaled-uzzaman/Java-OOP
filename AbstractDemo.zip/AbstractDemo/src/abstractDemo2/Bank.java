
package abstractDemo2;

public abstract class Bank {
    
    abstract int getRateOfInterest();
}
