
package abstractDemo2;

public class PNB extends Bank {
    
    @Override
    int getRateOfInterest()
    {
        return 8;
    }
}
