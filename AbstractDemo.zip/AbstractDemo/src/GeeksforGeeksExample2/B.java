
package GeeksforGeeksExample2;

public class B extends A {
    
    @Override
     void m1(){
        System.out.println("B's implementation of m2.");
    }
}
