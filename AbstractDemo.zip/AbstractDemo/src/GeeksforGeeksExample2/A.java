
package GeeksforGeeksExample2;
// abstract with class 
public abstract class A {
    
    // abstract with method 
    // it has no body 
    abstract void m1();
    
     // concrete methods are still allowed in abstract classes 
    void m2(){
        System.out.println("This is a concrete method.");
    }
}
