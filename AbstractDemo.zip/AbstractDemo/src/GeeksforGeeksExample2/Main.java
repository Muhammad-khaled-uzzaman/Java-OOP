
package GeeksforGeeksExample2;

public class Main {
    
    public static void main(String[] args) {
        
        B b = new B();
        b.m1();
        b.m2();
        
    }
}
