
package Example_5;

public class Demo {
    public static void main(String[] args) {
        Example2 ob = new Example2();
        ob.display1();
        ob.display2();
    }
}
