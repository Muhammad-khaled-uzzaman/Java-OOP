package Example_5;

public abstract class Example1 {

    private int numOne = 10;
    protected final int numTwo = 20;
    public static final int numThree = 500;
    public void display1() {
        System.out.println("Num1=" + numOne);
    }
}
