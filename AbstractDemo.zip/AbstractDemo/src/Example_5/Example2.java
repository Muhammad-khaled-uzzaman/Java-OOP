package Example_5;

public class Example2 extends Example1 {

    public void display2() {
        System.out.println("Num2=" + numTwo);
        System.out.println("Num2=" + numThree);
    }
}
