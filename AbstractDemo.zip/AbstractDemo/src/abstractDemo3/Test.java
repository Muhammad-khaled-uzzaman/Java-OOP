
package abstractDemo3;

public class Test {
    
    public static void main(String[] args) {
        
        Bike b;
        b = new Honda();
        
        b.run();
        b.changeGear();
    }
}
