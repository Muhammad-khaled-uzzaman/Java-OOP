
package abstractDemo3;

public class Honda extends Bike {
    
    @Override
    void run()
    {
        System.out.println("runing safely");
    }
}
