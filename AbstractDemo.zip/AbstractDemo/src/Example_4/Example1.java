
package Example_4;

public interface Example1 {
    
    public abstract void display1();
}
