package Example_4;

public class Example2 implements Example1 {

    @Override
    public void display1() {
        System.out.println("display1 method");
    }
}
