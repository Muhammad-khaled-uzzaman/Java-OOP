
package GeeksforGeeksExample_4;

public class Derived extends Base {
    
    Derived(){
        System.out.println("Derived Constructor Called");
    }
    
    @Override
    public void fun(){
        System.out.println("Derived fun() called");
    }
}
