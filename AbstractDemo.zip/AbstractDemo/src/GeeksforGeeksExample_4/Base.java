
package GeeksforGeeksExample_4;

public abstract class Base {
    Base(){
        System.out.println("Base Constructor Called");
    }
    abstract void fun();
}
