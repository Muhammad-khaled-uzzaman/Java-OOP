
package GeeksforGeeksExample3;

public abstract class Base {
    
    abstract void fun();
}
