
package GeeksforGeeksExample3;

public class Derived extends Base {
    
    @Override
    void fun(){
        System.out.println("Derived fun() called");
    }
    
}
