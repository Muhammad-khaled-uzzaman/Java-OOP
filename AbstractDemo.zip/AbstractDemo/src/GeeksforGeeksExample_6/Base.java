/*
bstract classes can also have final methods (methods that cannot be overridden). 
For example, the following program compiles and runs fine.
*/
package GeeksforGeeksExample_6;

public class Base {
    
    final void fun(){
        System.out.println("Derived fun() called");
    }
}
