
package GeeksforGeeksExample_6;

public class Derived extends Base {
    
}
