
package OutputExample;

public class Test extends Demo {
    
    @Override
    public void set(int a){
       this.a = a;
    }
    @Override
    public void get(){
        System.out.println("a = "+a);
        System.out.println("a = "+this.a);
    }
    public static void main(String[] args) {
        Test ob = new Test();
        ob.set(20);
        ob.get();
    }
}
