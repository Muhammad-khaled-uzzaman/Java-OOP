
package OutputExample;

public abstract class Demo {
    
    int a;
    public Demo(){
        a=10;
    }
    abstract public void set(int a);
    abstract  public void get();
}
