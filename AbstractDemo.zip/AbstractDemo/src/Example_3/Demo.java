
package Example_3;

public class Demo {
    public static void main(String[] args) {
        Example4 ob = new Example4();
        ob.display2();
    }
}
