package Example_3;

public abstract class Example2 {

    public void display2() {
        System.out.println("display2 method");
       
    }
}
