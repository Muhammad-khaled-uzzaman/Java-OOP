package Example_3;

public class Example1 {

    public void display1() {
        System.out.println("display1 method");
    }
}
