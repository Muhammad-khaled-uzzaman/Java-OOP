
package Example_3;

public abstract class Example3 extends Example2 {
    
   abstract void display3();
}
