package Example_3;

public class Example4 extends Example3 {

    @Override
    public void display2() {
        System.out.println("Example4-display2 method");
    }

    @Override
    public void display3() {
        System.out.println("display3 method");
    }
}
