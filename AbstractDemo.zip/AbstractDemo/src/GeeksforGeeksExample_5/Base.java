/*
n Java, we can have an abstract class without any abstract method. 
This allows us to create classes that cannot be instantiated, but can only be inherited.
*/
package GeeksforGeeksExample_5;

public abstract class Base {
    
    void fun(){
        System.out.println("Base fun() called");
    }
}
