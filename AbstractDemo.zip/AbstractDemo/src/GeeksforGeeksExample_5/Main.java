
package GeeksforGeeksExample_5;

public class Main {
    
    public static void main(String[] args) {
       Base d= new Derived();
       d.fun();
    }
}
