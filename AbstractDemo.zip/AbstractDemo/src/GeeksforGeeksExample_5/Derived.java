
package GeeksforGeeksExample_5;

public class Derived extends Base {
    @Override
    void fun(){
        
    }
}
