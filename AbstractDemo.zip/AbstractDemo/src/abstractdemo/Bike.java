/*
In this example, Bike is an abstract class that contains only one
abstract method run. Its implementation is provided by the Honda class.
*/
package abstractdemo;

public abstract class Bike {
    
    abstract void run();
}
