
package abstractdemo;

public class Honda extends Bike {

    
    @Override
    void run() {
        System.out.println("Runing safely");
    }
    public static void main(String[] args) {
        Bike b;
        b = new Honda();
        b.run();
    }
    
}
