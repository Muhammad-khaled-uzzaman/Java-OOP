
package Example_1;

public abstract class Example2 {
    
    public void display2(){
        System.out.println("display2 method...");
    }
}
