
package Example_1;

public class Demo {
    public static void main(String[] args) {
        Example4 ob = new Example4();
        
        ob.display3();
        ob.display1();
    }
}
