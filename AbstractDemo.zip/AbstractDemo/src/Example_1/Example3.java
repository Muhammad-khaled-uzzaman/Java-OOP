
package Example_1;

public abstract class Example3 extends Example1 {
    
    abstract void display3();
}
