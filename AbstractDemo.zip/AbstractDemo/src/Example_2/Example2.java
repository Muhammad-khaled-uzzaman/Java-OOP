
package Example_2;

public interface Example2 {
    
    public void display2();
}
