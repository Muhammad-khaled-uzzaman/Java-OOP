
package Example_2;

public class Example4 implements Example3{
    
    @Override
    public void display1(){
        System.out.println("display2 method"); 
    }
    
    @Override
    public void display2(){
        System.out.println("display3 method");
    }
}
