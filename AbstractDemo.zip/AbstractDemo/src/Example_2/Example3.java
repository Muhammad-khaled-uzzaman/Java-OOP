
package Example_2;

public interface Example3 extends Example1,Example2 {
    
}
