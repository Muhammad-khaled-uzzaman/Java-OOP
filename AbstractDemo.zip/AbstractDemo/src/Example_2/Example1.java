
package Example_2;

public interface Example1 {
    
    public void display1();
}
