
package GeeksforGeeksExample1;

public class Test {
    
    public static void foo(){
        System.out.println("Test.foo() called");
    }
    
    public static void foo(int a){
        System.out.println("Test.foo(int) called");
    }
    
    public static void main(String[] args) {
        Test t = new Test();
        t.foo();
        Test.foo(10); //better
        
    }
}
