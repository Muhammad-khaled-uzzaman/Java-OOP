
package GeeksforGeeksExample3;

public class Main {
    
    public static void main(String[] args) {
        Base ob = new Derived();
        
        ob.display();
        
        ob.print();
    }
    
}
