package GeeksforGeeksExample2;

public class Test {

    public static void foo() {
        System.out.println("Test.foo() called ");
    }

    /* 
    public void foo(){    // Compiler Error: cannot redefine foo() 
        System.out.println("Test.foo(int) called "); 
    }
     */
    
    public static void main(String[] args) {
        Test.foo();
    }
}
