//An inner class can access private members of its outer class
/* Java program to demonstrate whether we can override private method  
   of outer class inside its inner class */
package Example2;

public class Outer {

    private String msg = "Java T Point";

    private void fun() {
        System.out.println("Outer fun()");
    }

    public class Inner extends Outer {

        private void fun() {
            System.out.println("Accessing Private Member of Outer : " + msg);
        }
    }

    public static void main(String[] args) {
        Outer o = new Outer();
        
        Inner i = o.new Inner();

        i.fun();
        // o.fun() calls Outer's fun (No run-time polymorphism)
        o = i;
        o.fun();
        

        
    }
}
