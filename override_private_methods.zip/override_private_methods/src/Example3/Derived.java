
package Example3;

public class Derived extends Base {
    /*
    // compiler error  
    private void foo(){
        System.out.println("Derived");
    }
*/
    public static void main(String[] args) {
        Derived ob = new Derived();
        ob.foo();
    }
}
