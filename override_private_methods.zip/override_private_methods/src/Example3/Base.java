
package Example3;

public class Base {
    
    public void foo(){
        System.out.println("Base");
    }
}
