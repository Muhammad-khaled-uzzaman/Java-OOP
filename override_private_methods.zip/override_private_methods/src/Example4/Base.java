
package Example4;

public class Base {
    
    private void foo(){
        System.out.println("Base");
    }
}
