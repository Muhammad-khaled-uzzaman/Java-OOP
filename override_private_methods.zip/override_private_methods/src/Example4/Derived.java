
package Example4;

public class Derived extends Base {
    // works fine 
    public void foo(){
        System.out.println("Derived");
    }
}
