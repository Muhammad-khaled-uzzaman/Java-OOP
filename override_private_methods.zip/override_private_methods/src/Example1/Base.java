
package Example1;

public class Base {
    private void fun(){
        System.out.println("Base fun");
    }
}
