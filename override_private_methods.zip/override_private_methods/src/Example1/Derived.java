
package Example1;

public class Derived extends Base {
    
    private void fun(){  // fun() is not overridden.
        System.out.println("Derived fun");
    }
    public static void main(String[] args) {
       
        Base ob = new Derived();
        //ob.fun();  //compiler error
    }
}
