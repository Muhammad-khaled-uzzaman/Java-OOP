/*
Varargs and Ambiguity
 */
package Example3;

public class Test {

    static void fun(int... a) {
        System.out.println("fun(int ...): " + "Number of args: " + a.length
                + " Contents: ");

        for (int x : a) {
            System.out.print(x + " ");
        }

        System.out.println();
    }

    static void fun(boolean... a) {
        System.out.print("fun(boolean ...) "
                + "Number of args: " + a.length
                + " Contents: ");

        for (boolean x : a) {
            System.out.print(x + " ");
        }

        System.out.println();
    }
    public static void main(String[] args) {
        fun(1,2,3);
        fun(true,false,true);
        //fun(); // Error: Ambiguous! 
    }
}
