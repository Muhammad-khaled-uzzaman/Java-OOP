/*
Overloading main() in Java
 */
package Example4;

public class Test {

    public static void main(String[] args) {
        System.out.println("Hi Geek (from main)");
        Test.main("Geek");

    }

    public static void main(String args1) {
        System.out.println("Hi," + args1);
        Test.main("Dear Geek", "My Geek");
    }

    public static void main(String args1, String args2) {
        System.out.println("Hi," + args1 + " " + args2);
    }
}
