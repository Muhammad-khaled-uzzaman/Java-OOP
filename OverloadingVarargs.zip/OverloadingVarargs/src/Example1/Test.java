/*
Methods with only Varargs parameters:
double > float
float > long
long > int
int > char
int > short
short > byte
 */
package Example1;

public class Test {

    public static void fun(int... x) {
        System.out.println("int varargs");
    }

    public static void fun(char... x) {
        System.out.println("char varargs");
    }

    public static void fun(double... x) {
        System.out.println("double varargs");
    }

    public static void fun(long... x) {
        System.out.println("long varargs");
    }

    public static void fun(float... x) {
        System.out.println("float varargs");
    }

    public static void main(String[] args) {
        fun();
    }
}
