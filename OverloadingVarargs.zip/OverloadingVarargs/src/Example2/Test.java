/*
Methods with Varargs alongwith other parameters In this case, 
Java uses both the number of arguments and the type of the arguments to 
determine which method to call
 */
package Example2;

public class Test {

    public static void fun(int... a) {
        System.out.println("fun(int ...): " + "Number of args: " + a.length
                + " Contents: ");

        for (int x : a) {
            System.out.print(x + " ");
        }
        System.out.println();
    }

    public static void fun(boolean... x) {
        System.out.println("fun(boolean ...) " + "Number of args: " + x.length+" "
                + "Contents: ");

        for (boolean i : x) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void fun(String msg, int... a) {
        System.out.println("fun(String, int ...): " + msg + " "+  a.length
                + " Contents: ");

        for (int i : a) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        fun(1, 2, 3);
        fun("Muhammad", 5, 6);
        fun(true, false, true); 
    }

}
